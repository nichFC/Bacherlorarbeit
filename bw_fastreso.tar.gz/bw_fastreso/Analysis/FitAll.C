#include "TF1.h"
#include "TMath.h"
#include "TH3D.h"
#include "TFile.h"
#include "TGraphErrors.h"
#include "TMinuit.h"
#include "TCanvas.h"
#include "Scripts/BuildCanvas.C"
#include "Scripts/ProcessAxii.C"
#include "TList.h"
#include "VarSetup.C"
#include "TH2D.h"
//#include "Scripts/FitParameters.C"
#include "Scripts/Colors.h"
#include "TLine.h"
#include "TStopwatch.h"

Bool_t CalculateContours=kFALSE;//kFALSE;//kTRUE;
const Int_t nBWFit=3;//number of fitting species
Bool_t ScaleSpectra=kTRUE;//kFALSE;
Double_t ptmin=0.1;
Double_t ptmax=3.5;
Bool_t FreeNorm=kFALSE;//kTRUE;
Bool_t DisableHF=1;//kTRUE;



const Double_t MPion = 0.13957018;
const Double_t MKaon = 0.497648;
const Double_t MProton = 0.938272;
const Double_t MK0s = 0.497611;
const Double_t MXi = 1.3213;
Double_t masses[] = {MPion, MKaon, MProton,1.3,1.5};


TH3D *kernels[8][9];
TF1 **fBGBW;
TGraphErrors **gBW, *xi, *om;
TGraphErrors **gBWRat;
const char *kpf[] = {"Keq1", "Keq2","Kshear1","Kshear2","Kshear3","Kshear4",
                      "Kbulk1","Kbulk2"};
TList *lContours=0;
TGraphErrors *GetEmptyGraph() {
  return new TGraphErrors();
}
/* From Fitv2 */
inline double cs2FluiduM(double x) {
  return (x*x*(0.0010461910330715387 + x*(-0.016997351850612453 + x*(0.12595528994069613 + (-0.510477729039857 + x)*x)))*
     (3.831255349484765e-8 + x*(0.00002140058802480486 + x*(-0.00008693192041426982 +
             x*(-0.018444802527704172 + x*(0.5368632648594895 + x*(-7.4522565817870365 + x*(62.30776783074574 + x*(-336.8744183413884 + x*(1191.026405027395 + x*(-2590.1225767072065 + 2712.1934046206975*x)))))))))
       ))/(7.313548422127797e-15 + x*(8.356306148115294e-12 + x*(2.3387986355395423e-9 +
           x*(-6.605395132516945e-9 + x*(-1.790148526211301e-6 + x*(8.958041058260661e-6 +
                    x*(0.0014381954623440515 + x*(-0.045458133957877116 + x*(0.726263758547687 +
                             x*(-7.564793448616153 + x*(56.12131032495715 + x*(-308.4534327185232 +
                                      x*(1271.3766801470479 + x*(-3884.3701789306033 + x*(8436.311867208919 + x*(-11805.768858200583 + 8136.580213862093*x))))))))))))))));
};

void ResetContours();
void RescaleContourToMeanBeta(TGraph*,Double_t);
TF1 *fBGBlastWave_Integrand1=0;
TF1 *fBGBlastWave_Integrand2=0;

const Double_t MHBARC = 0.19732697;


void MultiplyGraphBy(TGraphErrors *ingr, Double_t k, Double_t ptpower=0) {
  if(!ingr) return;
  Double_t *x=ingr->GetX();
  Double_t *y=ingr->GetY();
  Double_t *xe=ingr->GetEX();
  Double_t *ye=ingr->GetEY();
  Double_t ptnorm=1;
  for(Int_t i=0;i<ingr->GetN();i++) {
    if(ptpower!=0) ptnorm=TMath::Power(x[i],ptpower);
    ingr->SetPoint(i,x[i],y[i]*k*ptnorm);
    ingr->SetPointError(i,xe[i],ye[i]*k*ptnorm);
  }
}
void FindMinMax(TGraphErrors *ingr, Double_t &ymin, Double_t &ymax, Double_t xmin, Double_t xmax) {
  Double_t *xvs = ingr->GetX();
  Double_t *yvs = ingr->GetY();
  if(ymin<0) ymin=yvs[0];
  if(ymax<0) ymax=yvs[0];
  for(Int_t i=0; i<ingr->GetN(); i++) {
    if(xvs[i]<xmin || xvs[i]> xmax) continue;
    if(ymin<yvs[i]) ymin=yvs[i];
    if(ymax>yvs[i]) ymax=yvs[i];
  }
}
Double_t integrand_1(Double_t pt, Double_t beta_max, Double_t n, int massind, Double_t Tkin, Double_t etas,Double_t zetas, Double_t rmax, Double_t tmax, Double_t beta,Double_t  r)
{
  Double_t cs2=cs2FluiduM(Tkin);
  Double_t Keq1    = kernels[0][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear1 = 0;//kernels[2][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear3 = 0;//kernels[4][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kbulk1  = 0;//kernels[6][massind]->Interpolate(pt,beta,Tkin);
  Double_t theta = 0;//( 1/TMath::Sqrt(1-beta*beta)/(1-cs2*beta*beta)*( (n+1)*beta/(r*rmax) + 1/tmax ) );
  Double_t bulkfactor =  0;//MHBARC *1/(15*TMath::Power(1./3.-cs2,2))*zetas/Tkin;
  Double_t shearfactor =  0;//MHBARC *etas/TMath::Power(Tkin,3);
  Double_t ExtraViscous=0;
  if(IncludeViscous) {
    Kshear1 = kernels[2][massind]->Interpolate(pt,beta,Tkin);
    Kshear3 = kernels[4][massind]->Interpolate(pt,beta,Tkin);
    Kbulk1  = kernels[6][massind]->Interpolate(pt,beta,Tkin);
    theta = ( 1/TMath::Sqrt(1-beta*beta)/(1-cs2*beta*beta)*( (n+1)*beta/(r*rmax) + 1/tmax ) );
    bulkfactor =  MHBARC *1/(15*TMath::Power(1./3.-cs2,2))*zetas/Tkin;
    shearfactor =  MHBARC *etas/TMath::Power(Tkin,3);
    ExtraViscous=bulkfactor*theta*Kbulk1 - shearfactor* ( 1/tmax/TMath::Sqrt(1-beta*beta)*Kshear1 + 1/(r*rmax)*beta/TMath::Sqrt(1-beta*beta)*Kshear3 -1.0/3.0 *(Kshear1+Kshear3)*theta );
  };
  // Speed of sound squared at freeze-out
  // Divergence of velocit D_mu u^mu in fm^-1
  return Keq1  + ExtraViscous;
}
Double_t integrand_2(Double_t pt, Double_t beta_max, Double_t m, int massind, Double_t Tkin, Double_t etas,Double_t zetas, Double_t rmax, Double_t tmax, Double_t beta,Double_t  t)
{
  Double_t cs2=cs2FluiduM(Tkin);
  Double_t Keq2    = kernels[1][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear2 = 0;
  Double_t Kshear4 = 0;
  Double_t Kbulk2  = 0;
  Double_t theta = 0;//( 1/TMath::Sqrt(1-beta*beta)/(1-cs2*beta*beta)*( (m+1)*beta/(rmax) + 1/(t*tmax) ) ); // because of integration add factor of 2 to 1/tau
  Double_t bulkfactor =  0;//MHBARC *1/(15*TMath::Power(1./3.-cs2,2))*zetas/Tkin;
  Double_t shearfactor =  0;//MHBARC *etas/TMath::Power(Tkin,3);
  Double_t ExtraViscous=0;
  if(IncludeViscous) {
    Kshear2=kernels[3][massind]->Interpolate(pt,beta,Tkin);
    Kshear4=kernels[5][massind]->Interpolate(pt,beta,Tkin);
    Kbulk2 =kernels[7][massind]->Interpolate(pt,beta,Tkin);
    theta = ( 1/TMath::Sqrt(1-beta*beta)/(1-cs2*beta*beta)*( (m+1)*beta/(rmax) + 1/(t*tmax) ) ); // because of integration add factor of 2 to 1/tau
    bulkfactor =  MHBARC *1/(15*TMath::Power(1./3.-cs2,2))*zetas/Tkin;
    shearfactor =  MHBARC *etas/TMath::Power(Tkin,3);
    ExtraViscous=bulkfactor*theta*Kbulk2 - shearfactor* ( 1/(t*tmax)/TMath::Sqrt(1-beta*beta)*Kshear2 + 1/(rmax)*beta/TMath::Sqrt(1-beta*beta)*Kshear4 -1.0/3.0 *(Kshear2+Kshear4)*theta );
  }
  // Speed of sound squared at freeze-out
  // Divergence of velocit D_mu u^mu in fm^-1
  return Keq2 + ExtraViscous;
}

Double_t BGBlastWave_Integrand1(const Double_t *x, const Double_t *p)
{
  /*
     x[0] -> r (radius)
     p[0] -> pT (transverse momentum)
     p[1] -> beta_max (surface velocity)
     p[2] -> T (freezout temperature)
     p[3] -> n (velocity profile)
     p[4] -> massInd (particle specie)
  */
  Double_t r = x[0];
  Double_t pt = p[0];
  Double_t beta_max = p[1];
  Int_t massind = TMath::Nint(p[4]);
  //  Double_t temp_1 = 1. / p[3];
  Double_t n = p[3];
  Double_t beta = beta_max * TMath::Power(r, n);
  Double_t Tkin = p[2];
  Double_t rmax = p[5];
  Double_t tmax = p[6];
  Double_t etas = p[7];
  Double_t zetas = p[8];
  Int_t ptind = kernels[0][massind]->GetXaxis()->FindBin(pt);
  Int_t betai = kernels[0][massind]->GetYaxis()->FindBin(beta);
  Int_t tempind = kernels[0][massind]->GetZaxis()->FindBin(Tkin);

  //printf("Attempting to evaluate kernel at (%f, %f, %f)\n",pt,beta,p[3]*1000);
  if(!kernels[0][0]) printf("Could not fetch kernels!\n");
  Double_t ker;
  //printf("%f, %f, %f, %i, %f, %f, %f, %f, %f, %f, %f\n",pt, beta_max, n, massind, Tkin, etas,zetas, rmax, tmax, beta, r);
  return r * integrand_1(pt, beta_max, n, massind, Tkin, etas,zetas, rmax, tmax, beta, r);
};

Double_t BGBlastWave_Integrand2(const Double_t *x, const Double_t *p)
{
  /*
     x[0] -> r (radius)
     p[0] -> pT (transverse momentum)
     p[1] -> beta_max (surface velocity)
     p[2] -> T (freezout temperature)
     p[3] -> n (velocity profile)
     p[4] -> massInd (particle specie)
  */
  Double_t t = x[0];
  Double_t pt = p[0];
  Double_t beta_max = p[1];
  Int_t massind = TMath::Nint(p[4]);
  //  Double_t temp_1 = 1. / p[3];
  Double_t m = p[3];
  Double_t beta = beta_max * TMath::Power(t, m);
  Double_t Tkin = p[2];
  Double_t rmax = p[5];
  Double_t tmax = p[6];
  Double_t etas = p[7];
  Double_t zetas = p[8];
  Int_t ptind = kernels[0][massind]->GetXaxis()->FindBin(pt);
  Int_t betai = kernels[0][massind]->GetYaxis()->FindBin(beta);
  Int_t tempind = kernels[0][massind]->GetZaxis()->FindBin(Tkin);

  //printf("Attempting to evaluate kernel at (%f, %f, %f)\n",pt,beta,p[3]*1000);
  if(!kernels[0][0]) printf("Could not fetch kernels!\n");
  Double_t ker;
  return t * integrand_2(pt, beta_max, m, massind, Tkin, etas,zetas, rmax, tmax, beta, t);
};


Double_t
BGBlastWave_Func_OneOverPt(const Double_t *x, const Double_t *p)
{
  Double_t pt = x[0];
  Double_t massInd = p[0];
  Double_t beta_max = p[1];
  Double_t temp = p[2];
  Double_t n = p[3];
  Double_t m = p[4];
  Double_t rmax = p[5];
  Double_t tmax = p[6];
  Double_t etas = p[7];
  Double_t zetas = p[8];
  Double_t ScalingFactor = p[9];
 //rmax = tmax;
 tmax = rmax; //new stuff
  Int_t IntmIND = TMath::Nint(massInd);
  //if(pt<rl[IntmIND] || pt > rh[IntmIND]) return 0;
  if (!fBGBlastWave_Integrand1) {
    fBGBlastWave_Integrand1 = new TF1("fBGBlastWave_Integrand1", BGBlastWave_Integrand1, 0., 1., 9);
    //fBGBlastWave_Integrand1->SetNpx(1000);
  };
  if (!fBGBlastWave_Integrand2) {
    fBGBlastWave_Integrand2 = new TF1("fBGBlastWave_Integrand2", BGBlastWave_Integrand2, 0., 1., 9);
    //fBGBlastWave_Integrand2->SetNpx(1000);
  };
  Double_t prs[] = {pt,beta_max,temp,n,massInd,rmax,tmax,etas,zetas};
  fBGBlastWave_Integrand1->SetParameters(pt, beta_max, temp, n, massInd,rmax,tmax,etas,zetas);
  Double_t integral1 = fBGBlastWave_Integrand1->Integral(0., 1., 1e-3);//GetSSFromBeta(beta_max));
  Double_t integral2=0;
  // if(IncludeViscous) { //new stuff
  //   fBGBlastWave_Integrand2->SetParameters(pt, beta_max, temp, m, massInd,rmax,tmax,etas,zetas);
  //   integral2 = fBGBlastWave_Integrand2->Integral(0., 1., 1e-3);//GetSSFromBeta(beta_max));
  // };
  return  ScalingFactor * rmax*tmax/TMath::Power(2*M_PI*MHBARC,3)*(  rmax*integral1 + tmax*integral2 );
};

void
BGBlastWave_FCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{

  // beta -> beta_max
  Double_t beta_max = par[1];
  Double_t T = par[2];
  Double_t n = par[3];
  Double_t m = par[0];
  Double_t rmax = par[4];
  Double_t tmax = par[5];
  Double_t etas = par[6];
  Double_t zetas = par[7];
  Double_t koverpi = par[8];
  Double_t poverpi = par[9];
  //Double_t beta_max = 0.5 * (2. + n) * beta;
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  // loop over all the data
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    Double_t scf=1;
    if(iBW==1) scf=koverpi;
    if(iBW==2) scf=poverpi;
    // set BGBW parameters
    fBGBW[iBW]->SetParameter(0,iBW*1.0);
    fBGBW[iBW]->SetParameter(1, beta_max);
    fBGBW[iBW]->SetParameter(2, T);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(4, par[0]);
    fBGBW[iBW]->SetParameter(5,rmax);
    fBGBW[iBW]->SetParameter(6,tmax);
    fBGBW[iBW]->SetParameter(7,etas);
    fBGBW[iBW]->SetParameter(8,zetas);
    fBGBW[iBW]->SetParameter(9,scf); //Scaling set to 1 for fitting
    if(iBW>=nBWFit) continue;
    //if(iBW!=2 && iBW!=1) continue;
    // loop over all the points
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(pt<rl[iBW] || pt>rh[iBW]) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  f = chi;
};

TGraphErrors *HtoGr(TH1 *inh, Double_t ptlow, Double_t pthigh) {
  TGraphErrors *retgr = new TGraphErrors();
  Int_t pcount = 0;
  for(Int_t i=inh->FindBin(ptlow+1e-6); i<=inh->FindBin(pthigh-1e-6); i++) {
    retgr->SetPoint(pcount,inh->GetBinCenter(i),inh->GetBinContent(i));
    retgr->SetPointError(pcount,inh->GetBinWidth(i)/2,inh->GetBinError(i));
    pcount++;
  };
  return retgr;
};
TGraphErrors *HtoGr(TH1 *inh) {
  Double_t ptlow = inh->GetBinCenter(1);
  Double_t pthigh = inh->GetBinCenter(inh->GetNbinsX());
  return HtoGr(inh,ptlow,pthigh);
};
TGraphErrors *MakeRatio(TGraphErrors *ingr, TF1 *inf, Bool_t Debug=kFALSE) {
  TGraphErrors *retgr = new TGraphErrors();
  retgr->SetPoint(0,0.,0.);
  Double_t x,y,xe,ye;
  for(Int_t i=0;i<ingr->GetN(); i++) {
    ingr->GetPoint(i,x,y);
    if(x>ptmax) break;
    if(x<ptmin) continue;
    xe = ingr->GetErrorX(i);
    ye = ingr->GetErrorY(i);
    Int_t np = retgr->GetN();
    retgr->SetPoint(np,x,y/inf->Eval(x));
    if(Debug) printf("Debug: x(%f), y(%f) vs. function y(%f)\n",x,y,inf->Eval(x));
    retgr->SetPointError(np,xe,ye/inf->Eval(x));
  };
  return retgr;
};
void PreloadSpectra(Int_t cent) {
  TFile *tf = new TFile(infile.Data(),"READ");
  const char *pikpnames[] = {"pi","ka","pr","Lambda","Xi","Omega","Dc","Ds","LambdaC"};
  if(gBW && nBW) {
    for(Int_t i=0;i<nBW;i++) delete gBW[i];
    delete [] gBW;
  }
  nBW=GetNBW(cent);
  gBW = new TGraphErrors*[nBW];
  for(Int_t i=0;i<nBW;i++) {
    gBW[i] = (TGraphErrors*)tf->Get(Form(ingrdesc.Data(),pikpnames[i],centr));
    if(!gBW[i]) gBW[i] = GetEmptyGraph();
  };
  tf->Close();
}
void Init(Int_t cent, Bool_t ForceReload=kFALSE) { //Set ForceReload to force reload kernels (important if fittype has changed)
  SetupVariables(selsys);
  SetupFitType(fittype);
  PreloadSpectra(cent);
  if(!kernels[0][0] || ForceReload) {
    // if(kernels[0][0]) { //If kernels preloaded, delete them
    //   for(Int_t j=0;j<8;j++)
    //     for(Int_t i=0;i<6;i++)
    //     delete kernels[i][j];
    // }
    const char *nams[] = {"pi0139plu","Ka0492plu","pr0938plu","Lm1115zer","Xi1321min","UM1672min","Dc1865zer","Ds1968plu","Lc2286plu"};//{"pions","kaons","protons","Xi","Om"};
    TFile *tf = new TFile(KernelFile.Data(),"READ");
    printf("Reading kernels ");
    for(Int_t j=0;j<8;j++) {
      if(!IncludeViscous) if(j>1) continue;
      for(Int_t i=0;i<nBW;i++) {
        printf(".");
        kernels[j][i] = (TH3D*)tf->Get(Form("%s_%s",nams[i],kpf[j]));
        if(!kernels[j][i]) printf("Could not read find in file %s!\n",tf->GetTitle());
        kernels[j][i] = (TH3D*)kernels[j][i]->Clone(Form("%s_%s",nams[i],kpf[j]));
        kernels[j][i]->SetDirectory(0);
      };
    };
    printf("\n");
    tf->Close();
  };
  fBGBW = new TF1*[nBW];
  for(Int_t i=0;i<nBW;i++) fBGBW[i] = new TF1(Form("BGBW_%i",i),BGBlastWave_Func_OneOverPt,ptmin,ptmax,10);
};
void CopyParsToBW(TMinuit *mn) {
  Double_t parvals[10], parerrs[10];
  for(Int_t i=0;i<10;i++)
    mn->GetParameter(i,parvals[i],parerrs[i]);
  for(Int_t i=0;i<nBW;i++) {
    Double_t scf=1;
    if(i==1) scf=parvals[8];
    if(i==2) scf=parvals[9];
    fBGBW[i]->SetParameter(0,i); //index
    fBGBW[i]->SetParameter(4,parvals[0]); //norm
    fBGBW[i]->SetParameter(9,scf);//
    for(Int_t j=1;j<9;j++) {
      if(j==4) continue; //norm set earlier
      fBGBW[i]->SetParameter(j,parvals[j<5?j:(j-1)]); //for pars 5-8 j->j-1 (since TF1 par. 4 = Minuit[0] and shifts everything else)
    }
  }
}
TCanvas *DrawLambdaRatios() {
    TCanvas *retcan = BuildSingleCanvas(600,600);
    fBGBW[8]->SetRange(0.5,15);
    fBGBW[6]->SetRange(0.5,15);
    TH1 *lc = fBGBW[8]->GetHistogram();
    TH1 *dc = fBGBW[6]->GetHistogram();
    lc->Divide(dc);
    lc->SetTitle(";#it{p}_{T} (GeV/#it{c}); #Lambda_{c}/D_{c}");
    lc->Draw();
    delete dc;
    TLegend *leg = Legend(.2,.7,.5,.9);
    leg->AddEntry(leg,LegDesc.Data(),"L");
    leg->Draw();
    return retcan;
}
void SaveLambdaRatios(const char *filename = "LambdaOverDc/LambdaOverDc.root") {
  if(DisableHF) return;
  TFile *tempfile = new TFile(filename,"UPDATE");
  fBGBW[8]->SetRange(0.5,15);
  fBGBW[6]->SetRange(0.5,15);
  fBGBW[8]->SetNpx(58);
  fBGBW[6]->SetNpx(58);
  TH1 *lc = fBGBW[8]->GetHistogram();
  TH1 *dc = fBGBW[6]->GetHistogram();
  lc->Divide(dc);
  lc->SetTitle(Form("%s, %s;#it{p}_{T} (GeV/#it{c}); #Lambda_{c}/D_{c}",fittypePF.Data(),PbPbHFBins[centr]));
  lc->SetName(Form("%s_%i",fittypePF.Data(),centr));
  delete dc;
  lc->Write();
  tempfile->Close();
}

TMinuit* PerformFit(Bool_t DrawFit=kFALSE, Int_t l_cent=-1, Double_t tkinfix=-1, Double_t betamax=-1) {
  if(l_cent>-1) centr=l_cent;
  Init(l_cent);
  TMinuit *minuit = new TMinuit(10);
  minuit->SetFCN(BGBlastWave_FCN);
  Double_t arglist[10];
  Int_t ierflg = 0;
  arglist[0] = 1;
  minuit->mnexcm("SET ERR", arglist, 1, ierflg);
  Double_t norms[] = {2770,1940,800,10,10};
  minuit->mnparm(0, "m", 1, 0.0001, 0.0001, 5., ierflg);
  minuit->mnparm(1, "beta_max", 0.8, 0.01, 0.3, 0.985, ierflg);
  minuit->mnparm(2, "T", 0.1565, 0.001, TkinMin, TkinMax, ierflg);
  minuit->mnparm(3, "n", 1., 0.001, 1e-2, 10., ierflg);
  minuit->mnparm(4, "rmax",12,0.5,0,50, ierflg);
  minuit->mnparm(5, "tmax",10,0.5,0,50, ierflg);
  minuit->mnparm(6, "etas", 0.0, 0.01,-5,5, ierflg);
  minuit->mnparm(7, "zetas", 0.0, 0.01, -5, 5, ierflg);
  minuit->mnparm(8, "KoverPi",1., 0.01, 0.01, 2, ierflg);
  minuit->mnparm(9, "PoverPi",1., 0.01, 0.01, 10, ierflg);
  minuit->FixParameter(0); //new stuff
  minuit->FixParameter(6); //new stuff
  minuit->FixParameter(5); //new stuff
  //minuit->FixParameter(2); //For Johanna & PBM
  if(!IncludeViscous) {
    minuit->FixParameter(0);
    minuit->FixParameter(5);
    minuit->FixParameter(6);
    minuit->FixParameter(7);
  };
  if(!FreeNorm) {
    minuit->FixParameter(8);
    minuit->FixParameter(9);
  }
  if(tkinfix>0) {
    minuit->mnparm(2,"Tfixed",tkinfix,0.1,tkinfix-0.1,tkinfix+0.1,ierflg);
    minuit->FixParameter(2);
    //minuit->mnparm(1,"beta_fix",tkinfix,0.1,tkinfix-0.1,tkinfix+0.1,ierflg);
    //minuit->FixParameter(1);
  }
  if(betamax>0) {
    minuit->mnparm(1,"beta_fix",betamax,0.1,betamax-0.1,betamax+0.1,ierflg);
    minuit->FixParameter(1);
  }
  /*
  minuit->mnexcm("SET ERR", arglist, 1, ierflg);
  Double_t norms[] = {1770,1940,800,10,10};
  minuit->mnparm(0, "Norm_K1", 400, 10., 1., 1600., ierflg);
  minuit->mnparm(1, "beta_max", 0.6, 0.01, 0.1, 0.985, ierflg);
  minuit->mnparm(2, "T", 0.140, 0.001, 0.131, 0.179, ierflg);
  minuit->mnparm(3, "n", 1, 0.01, 0.1, 10., ierflg);*/
  //minuit->FixParameter(3);
  TStopwatch *stw = new TStopwatch();
  stw->Start(kTRUE);
  arglist[0] = 1;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n First MIGRAD ierflg: %i\n\n\n",ierflg);

  /* set strategy */
  arglist[0] = 2;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  printf("\n\n\n Set Strategy ierflg: %i\n\n\n",ierflg);

  //UseInterpolated=kTRUE;

  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n Second ierflg: %i\n\n\n",ierflg);


  /* start IMPROVE minimization */
  //arglist[0] = 500000;
  minuit->mnexcm("IMPROVE", arglist, 1, ierflg);
  printf("\n\n\n IMPROVE ierflg: %i\n\n\n",ierflg);

  /* start MINOS */
  arglist[0] = 500000;
  arglist[1] = 1;
  arglist[2] = 2;
  arglist[3] = 3;
  arglist[4] = 4;
  arglist[5] = 5;
  arglist[6] = 6;
  arglist[7] = 7;
  arglist[8] = 8;
  arglist[9] = 9;
  //arglist[8] = 7;
  minuit->mnexcm("MINOS", arglist, 4, ierflg);
  Double_t amin,edm,errdef;
  Int_t nvpar,nparx,icstat;
  minuit->mnstat(amin, edm, errdef, nvpar, nparx, icstat);
  minuit->mnprin(9, amin);
  stw->Stop();
  if(CalculateContours) {
    minuit->SetErrorDef(1);
    //Limit nmax, otherwise, can't calculate proper contours in some cases
    Double_t nval, nerr, nvalr;
    minuit->GetParameter(3,nval,nerr);
    nvalr=nval+5.5;
    TGraph *grc=0;
    while(!grc) { //While no grc
        nvalr-=0.5;
        if(nvalr<nval) break; //In case max goes below original value, break
        minuit->mnparm(3, "n", 1, 0.01, 0.1, nvalr, ierflg);
        grc = (TGraph*)minuit->Contour(80,1,2);
        if(grc) if(grc->GetN()<80) {
          delete grc;
          grc=0;
        };
    };
    if(grc) {
      grc->SetName(Form("%sContour_%i",syspf.Data(),centr));
      RescaleContourToMeanBeta(grc,nval);
      if(!lContours) ResetContours();
      lContours->Add(grc);
    } else printf("Could not calculate contour for %s, centrality %i\n",syspf.Data(),centr);
  }
  printf("\n***********************************************\n");
  printf("Total time for fitting: %f",stw->RealTime());
  printf("\n***********************************************\n");
  delete stw;
  CopyParsToBW(minuit);
  printf("Storing lambda rations...\n");
  SaveLambdaRatios();
  printf("Done!\n");
  //TCanvas *c2 = DrawLambdaRatios();
  //TString savepf="LambdaCRatios.pdf";
  //if(!l_cent) savepf.Append("(");
  //if(l_cent==nSpectraAA) savepf.Append(")");
  //printf("l_cent = %i\tnSpectraAA = %i\tSave file = %s\n",l_cent,nSpectraAA,savepf.Data());
  //c2->Print(savepf.Data());
  //delete c2;
  if(!DrawFit) return minuit;
  Int_t colind = CreateColors(nBW);
  Int_t cols[] = {kRed+1, kBlue+1, kGreen+2, kMagenta+2, kBlack, kYellow};
  gBWRat = new TGraphErrors*[nBW];
  /*
  TCanvas *c = BuildParallelRatios(600,200,nBW);
  TPad *tp;
  TLegend *leg = Legend(.44,.8,.76,.98);//.21,0.14,.53,.32);//396411,.58435,.941272,.885085);
  leg->AddEntry((TObject*)0x0,LegDesc.Data(), "h");
  leg->SetNColumns(2);
  TString snams[] = {"#pi","K","p","#Lambda+#bar{#Lambda}","#Xi","#Omega"};
  Int_t ScaleFactors[] = {10,10,5,1,1,1,1};
  Double_t ymin=-1;
  Double_t ymax=-1;
  for(Int_t i=0;i<nBW;i++) {
    if(ScaleSpectra) {
      MultiplyGraphBy(gBW[i],ScaleFactors[i]);
      fBGBW[i]->SetParameter(9,ScaleFactors[i]);
      if(ScaleFactors[i]!=1) snams[i].Append(Form(" #times %i",ScaleFactors[i]));
    };
    FindMinMax(gBW[i],ymin,ymax,ptmin,ptmax);
  };
  TGraph *dummygr = new TGraph();
  dummygr->SetPoint(0,ptmin,0.8*ymin);
  dummygr->SetPoint(1,ptmax,1.2*ymax);
  ProcessAxisPx(dummygr->GetYaxis(),25,0.005,30,1.6,505,0.02);
  ProcessAxisPx(dummygr->GetXaxis(),25,0.005,30,1.2,506,0.02);
  dummygr->GetYaxis()->SetTitle("#frac{1}{#it{N}_{ev}}#frac{1}{2#pi#it{p}_{T}}#frac{d^{2}#it{N}}{d#it{y}d#it{p}_{T}} [GeV^{2}]");
  dummygr->GetXaxis()->SetTitle("#it{p}_{T} (GeV/#it{c})");
  dummygr->GetXaxis()->SetRangeUser(ptmin,ptmax*1.01);
  TGraph *dummyra = new TGraph();
  dummyra->SetPoint(0,ptmin,0.1);
  dummyra->SetPoint(1,ptmax,1.9);
  ProcessAxisPx(dummyra->GetYaxis(),25,0.005,30,1.2,405,0.02);
  ProcessAxisPx(dummyra->GetXaxis(),25,0.005,30,4,506,0.02);
  dummyra->GetYaxis()->SetTitle("Data/Fit");
  dummyra->GetXaxis()->SetTitle("#it{p}_{T} (GeV/#it{c})");
  dummyra->GetXaxis()->SetRangeUser(ptmin,ptmax*1.01);
  dummyra->GetYaxis()->SetRangeUser(0.1,1.9);
  TGraph *dummyra2 = (TGraph*)dummyra->Clone();
  dummyra2->GetYaxis()->SetTitle("");
  tp = (TPad*)c->FindObject("left");
  tp->cd();
  dummygr->Draw("AP");
  printf("\n\n\n min/max: %f/%f\n",ymin,ymax);*/
  for(Int_t i=0;i<nBW;i++) {
/*    tp = (TPad*)c->FindObject("left");
    tp->cd();
    gBW[i]->Draw("SAME P");
    if(!i) {
      tp->SetLogy();
    };
    gBW[i]->SetLineColor(colind+i);
    leg->AddEntry(gBW[i],snams[i].Data(),"L");
    if(i==2) leg->Draw();
    fBGBW[i]->SetLineColor(colind+i);
    fBGBW[i]->SetRange(ptmin>0?ptmin:0.1,ptmax);
    fBGBW[i]->Draw("SAME L");
    tp = (TPad*)c->FindObject(Form("right_%i",i));
    tp->cd();*/
    gBWRat[i] = MakeRatio(gBW[i],fBGBW[i]);
    gBWRat[i]->SetLineColor(kBlack);//colind+i);
/*    if(i) dummyra2->Draw("AP");    else dummyra->Draw("AP");
    gBWRat[i]->Draw("SAME P");

    if(i) gBWRat[i]->GetYaxis()->SetTitle("");
    ProcessAxisPx(gBWRat[i]->GetYaxis(),25,0.005,30,1.2,405,0.02);
    ProcessAxisPx(gBWRat[i]->GetXaxis(),25,0.005,30,4,506,0.02);
    TLine *tl = new TLine(ptmin,1.,ptmax,1);
    tl->SetLineColor(kBlack);
    tl->SetLineStyle(2);
    tl->Draw("SAME");*/
    TFile *bwratfi = new TFile("OtherOutput/BWRatios.root","UPDATE");
    gBWRat[i]->Write(Form("Ratio_%s_%i_cent_%i_%s",syspf.Data(),i,centr,fittypePF.Data()),TObject::kOverwrite);
    gBW[i]->Write(Form("Spectra_%s_%i_cent_%i_%s",syspf.Data(),i,centr,fittypePF.Data()),TObject::kOverwrite);
    fBGBW[i]->Write(Form("Fit_%s_%i_cent_%i_%s%s",syspf.Data(),i,centr,fittypePF.Data(),FreeNorm?"_FreeNorm":""),TObject::kOverwrite);
    bwratfi->Close();
//    printf("Finished with %s, cent. ind. %i\n",syspf.Data(),centr);
  };
  /*const char *sf="";
  if(nSpectraAA!=1) {
    if(!centr) sf="(";
    if(centr==nSpectraAA-1)
      sf=")";
    };
  c->Print(Form("Output/SpectraComp/%s%s.pdf%s",syspf.Data(),ConfigSF.Data(),sf));*/
  return minuit;
};
Double_t CalculateChiSquared() {
  Double_t chisq=0;
  for(Int_t iBW=0;iBW<nBWFit;iBW++) {
    //if(iBW==1) continue;
    Double_t *pts = gBW[iBW]->GetX();
    Double_t *yvs = gBW[iBW]->GetY();
    Double_t *yes = gBW[iBW]->GetEY();
    Double_t fval, pull;
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      if(pts[ipt]<rl[iBW] || pts[ipt]>rh[iBW]) continue;
      fval = fBGBW[iBW]->Eval(pts[ipt]);
      pull = (yvs[ipt] - fval)/yes[ipt];
      chisq+=(pull*pull);
    }
  }
  return chisq;
}
Int_t CalculateNDF() {
  Int_t ndf=0;
  for(Int_t iBW=0;iBW<nBWFit;iBW++) {
    Double_t *pts = gBW[iBW]->GetX();
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      if(pts[ipt]<rl[iBW] || pts[ipt]>rh[iBW]) continue;
      ndf++;
    }
  }
  return ndf;
}
TGraph **GetChiSqVsTemp(Int_t cent, Double_t tMin, Double_t tMax, Double_t tStep) {
  TGraph **retgr = new TGraph*[2];
  retgr[0] = new TGraph();
  retgr[1] = new TGraph();
  for(Double_t tcurr=tMin; tcurr<tMax; tcurr+=tStep) {
    TMinuit *mn = PerformFit(kFALSE,cent,tcurr);
    Double_t tkin, tkinerr, n, nerr, bmax, bmaxerr;
    mn->GetParameter(1,bmax,bmaxerr);
    mn->GetParameter(2,tkin,tkinerr);
    mn->GetParameter(3,n,nerr);
    Double_t mbeta = bmax/(0.5*(2+n));
    Double_t chisq = CalculateChiSquared();
    Int_t ndf = CalculateNDF()-mn->GetNumFreePars();
    Int_t cp = retgr[0]->GetN();
    retgr[0]->SetPoint(cp,tcurr,chisq/ndf);
    retgr[1]->SetPoint(cp,tkin,n);//bmax);//mbeta);
  }
  return retgr;
}
TGraph *GetChiSqVsBeta(Int_t cent, Double_t bMin, Double_t bMax, Double_t bStep) {
  TGraph *retgr=new TGraph();
  for(Double_t bcurr=bMin; bcurr<bMax; bcurr+=bStep) {
    TMinuit *mn = PerformFit(kFALSE,cent,-1,bcurr);
    Double_t chisq = CalculateChiSquared();
    Int_t ndf = CalculateNDF()-mn->GetNumFreePars();
    if(chisq/ndf>20) continue;
    Double_t b, berr, n, nerr, tkin, tkinerr;
    mn->GetParameter(2,tkin,tkinerr);
    mn->GetParameter(1,b,berr);
    Int_t cp = retgr->GetN();
    retgr->SetPoint(cp,b,tkin);
    // mn->GetParameter(3,n,nerr);
    // Double_t mbeta = bcurr/(0.5*(2+n));
    // Double_t chisq = CalculateChiSquared();
    // Int_t ndf = CalculateNDF()-mn->GetNumFreePars();
    // Int_t cp = retgr->GetN();
    // retgr->SetPoint(cp,tcurr,chisq/ndf);
  }
  return retgr;
}
TH2D *GetChiSqVsTempAndBeta(Int_t cent, Double_t tMin, Double_t tMax, Double_t tStep, Double_t betamin, Double_t betamax, Double_t betastep) {
  TH2D *reth2 = new TH2D("h2","h2",(betamax-betamin)/betastep+1,betamin-betastep/0.5,betamax+betastep/0.5,(tMax-tMin)/tStep+1,tMin-tStep/0.5,tMax+tStep/0.5);
  for(Double_t tcurr=tMin; tcurr<=tMax; tcurr+=tStep) {
    for(Double_t bcurr=betamin; bcurr<=betamax; bcurr+=betastep) {
      TMinuit *mn = PerformFit(kFALSE,cent,tcurr,bcurr);
      Int_t binindX = reth2->GetXaxis()->FindBin(bcurr);
      Int_t binindY = reth2->GetYaxis()->FindBin(tcurr);
      Double_t chisq = CalculateChiSquared();
      Int_t ndf = CalculateNDF()-mn->GetNumFreePars();
      reth2->SetBinContent(binindX,binindY,chisq/ndf);
    }
  }
  return reth2;
}
void Draw2DChiSqAllCents(const char *filename) {
  for(Int_t i=0;i<nSpectraAA;i++) {
    FreeNorm=kTRUE;
    TH2D *h2 = GetChiSqVsTempAndBeta(i,0.12,0.198,0.003,0.5,0.9,0.005);
    FreeNorm=kFALSE;
    TGraph *gr = GetChiSqVsBeta(i,0.5,0.9,0.005);
    h2->SetName(Form("FreeNorm_cent%i",i));
    gr->SetName(Form("FixedNorm_cent%i",i));
    TFile *tf = new TFile(filename,"UPDATE");
    h2->Write();
    gr->Write();
    tf->Close();
  }
}
Double_t CalculateChiSquared(Double_t beta1, Double_t Tkin, Double_t norm1, Double_t n) {
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    // set BGBW parameters
    fBGBW[iBW]->SetParameter(0, iBW*1.0);
    fBGBW[iBW]->SetParameter(1, beta1);
    fBGBW[iBW]->SetParameter(2, Tkin);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(4, norm1);

    // loop over all the points
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(rl[iBW] > pt || rh[iBW]<pt) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  return chi;
};
void ResetContours() {
  if(lContours)
    delete lContours;
  lContours = new TList();
  lContours->SetName(Form("ContourList%s",ConfigSF.Data()));
  lContours->SetOwner(kTRUE);
};
void RescaleContourToMeanBeta(TGraph *ingr, Double_t n) {
  Double_t x,y;
  for(Int_t i=0;i<ingr->GetN();i++) {
    ingr->GetPoint(i,x,y);
    x = x/(0.5*(2+n));
    ingr->SetPoint(i,x,y);
  }
}
void PlotFreezeOut(Bool_t DrawPerformance=kFALSE) {
  SetupVariables(selsys);
  TGraphErrors *gr = new TGraphErrors();
  FILE *outputpars = fopen(Form("../FitParameters/%s.txt",syspf.Data()),"a+");
  TString fixedpars("");
  fixedpars.Append("Single kernel ");
  fprintf(outputpars,"\n\n#%s, fit pions[%1.1f-%1.1f], kaons [%1.1f-%1.1f], protons [%1.1f-%1.1f]. Fit type: %s. %s\n",
	  syspf.Data(),rl[0],rh[0],rl[1],rh[1],rl[2],rh[2],fittypePF.Data(),fixedpars.Data());
  const char *outlabs[] = {
      "#Cmin","Cmax",
      "m","mErr",
      "betaMax","betaMaxErr",
      "Tkin","TkinErr",
      "n","nErr",
      "rMax","rMaxErr",
      "tMax","tMaxErr",
      "etas","etasErr",
      "zetas","zetasErr",
      "KoPi","KoPiErr",
      "PoPi","PoPiErr",
      "ChiSq","NDF",
      "ChiSq/NDF\n"
  };
  fprintf(outputpars,"%4s%6s",outlabs[0],outlabs[1]);
  for(Int_t i=2;i<25;i++) fprintf(outputpars,"%12s",outlabs[i]);
  Double_t Outprs[12];
  Double_t Outerr[12];
  const char *formats[] = {
    "%4.0f%7.0f",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.3e",
    "%12.3e%12.0f",
    "%12.3e\n"
  };
  gr->SetPoint(0,0,0);
  TObjArray *oba = new TObjArray();
  oba->SetOwner(kTRUE);
  for(Int_t i=0;i<nSpectraAA;i++) {
    centr=i;
    Init(i);
    TMinuit *mn = PerformFit(DrawPerformance,i);
    Double_t chisq = CalculateChiSquared();
    Int_t ndf = CalculateNDF()-mn->GetNumFreePars();
    Outprs[0] = centLow;
    Outerr[0] = centHigh;
    for(Int_t i=0;i<10;i++) mn->GetParameter(i,Outprs[i+1],Outerr[i+1]);
    Outprs[11]=chisq;
    Outerr[11]=ndf;
    for(Int_t i=0;i<12;i++) fprintf(outputpars,formats[i],Outprs[i],Outerr[i]);
    fprintf(outputpars,formats[12],Outprs[11]/Outerr[11]);
    Double_t b1,tk,b1e,tke,n,ne,n1,n1e;
    mn->GetParameter(0,n1,n1e);
    mn->GetParameter(1,b1,b1e);
    mn->GetParameter(2,tk,tke);
    mn->GetParameter(3,n,ne);
    Int_t np = gr->GetN();
    gr->SetPoint(np,b1/(0.5*(2+n)),tk);
    gr->SetPointError(np,b1e/(0.5*(2+n)),tke);
  };
  Int_t np=gr->GetN();
  gr->SetPoint(np,1,0.2);
  fclose(outputpars);
  gr->SetTitle(";#LT#beta_{T}#GT;T_{kin}");
  TCanvas *c = new TCanvas("tkin","tkin",600,600);
  gr->Draw("AP");
  gr->SetName(Form("%s%s_%s",syspf.Data(),ConfigSF.Data(),fittypePF.Data()));
  if(CalculateContours) {
    TGraph *betatp = new TGraph();
    for(Int_t i=0;i<gr->GetN();i++) betatp->SetPoint(i,gr->GetX()[i],gr->GetY()[i]);
    betatp->SetName(Form("%s_%s",syspf.Data(),fittypePF.Data()));
    lContours->Add(betatp);
  };
  TFile *tf = new TFile(Form("Output/BetaT/%s.root",syspf.Data()),"UPDATE");
  gr->Write(0,TObject::kOverwrite);
  tf->Close();
};
void PlotAll(TString configname) {
  ReadConfig(configname);
  //ResetContours();
  selsys=kpp7;
  PlotFreezeOut(kFALSE);
  selsys=kPbPb276;
  PlotFreezeOut(kFALSE);
  selsys=kpPb502;
  PlotFreezeOut(kFALSE);
  /*if(CalculateContours) {
    TFile *tf = new TFile("Output/BetaT/Contours.root","UPDATE");
    lContours->Write(0,TObject::kOverwrite+TObject::kSingleKey);
    tf->Close();
  };*/
};
void PlotAllMS(TString configname) {
  ReadConfig(configname);
  ResetContours();
  selsys=kPbPb276MS;
  PlotFreezeOut(kTRUE);
  return;
  selsys=kpp7MS;
  PlotFreezeOut(kTRUE);
  selsys=kpPb502;
  PlotFreezeOut(kTRUE);
  if(CalculateContours) {
    TFile *tf = new TFile("Output/BetaT/Contours.root","UPDATE");
    lContours->Write(0,TObject::kOverwrite+TObject::kSingleKey);
    tf->Close();
  };
};
void PlotWithPCE() {
  SetupFitType(kPCE140);
  Init(0,1);
  PlotAll("Nominal");
  SetupFitType(kPCE145);
  Init(0,1);
  PlotAll("Nominal");
  SetupFitType(kPCE150);
  Init(0,1);
  PlotAll("Nominal");
  SetupFitType(kPCE155);
  Init(0,1);
  PlotAll("Nominal");
  SetupFitType(kPCE160);
  Init(0,1);
  PlotAll("Nominal");
  SetupFitType(kPCE165);
  Init(0,1);
  PlotAll("Nominal");
  SetupFitType(kNormal);
  Init(0,1);
  PlotAll("Nominal");
}
void DrawPerformanceWithMS() {
  ScaleSpectra=kTRUE;
  ReadConfig("Nominal");
  ResetContours();
  CalculateContours=kFALSE;
  selsys=kpp7MS;
  SetupVariables(selsys);
  for(Int_t i=0;i<nSpectraAA;i++) TMinuit *mn = PerformFit(kTRUE,i);
  selsys=kPbPb276MS;
  SetupVariables(selsys);
  for(Int_t i=0;i<nSpectraAA;i++) TMinuit *mn = PerformFit(kTRUE,i);
  selsys=kpPb502;
  SetupVariables(selsys);
  for(Int_t i=0;i<nSpectraAA;i++) TMinuit *mn = PerformFit(kTRUE,i);
};
void DrawPerformanceNormal() {
  ScaleSpectra=kFALSE;
  ReadConfig("Nominal");
  ResetContours();
  CalculateContours=kFALSE;
  selsys=kpp7;
  SetupVariables(selsys);
  for(Int_t i=0;i<nSpectraAA;i++) TMinuit *mn = PerformFit(kTRUE,i);
  printf("Done with pp\n");
  selsys=kpPb502;
  SetupVariables(selsys);
  for(Int_t i=0;i<nSpectraAA;i++) TMinuit *mn = PerformFit(kTRUE,i);
  printf("Done with pPb\n");
  selsys=kPbPb276;
  SetupVariables(selsys);
  for(Int_t i=0;i<nSpectraAA;i++) TMinuit *mn = PerformFit(kTRUE,i);
  printf("Done with PbPb\n");

}

void PlotAll(){
  PlotAll("Nominal");
  PlotAll("Original");
  PlotAll("LowPt");
  PlotAll("HighPt");
}
void PrepareSpectraRatios(FitDesc ft) {
  SetupFitType(ft);
  SetupVariables(kPbPb276MS);
  PlotFreezeOut(kTRUE);
  SetupVariables(kPbPb502);
  PlotFreezeOut(kTRUE);
  SetupVariables(kpp7MS);
  PlotFreezeOut(kTRUE);
}
void CreateTablesDiffFitTypes() {
  SetupFitType(kNormal);
  Init(0,kTRUE);
  PlotFreezeOut();
  SetupFitType(kPCE140);
  Init(0,kTRUE);
  PlotFreezeOut();
  SetupFitType(kPCE145);
  Init(0,kTRUE);
  PlotFreezeOut();
  SetupFitType(kPCE150);
  Init(0,kTRUE);
  PlotFreezeOut();
  SetupFitType(kPCE155);
  Init(0,kTRUE);
  PlotFreezeOut();
  SetupFitType(kPCE160);
  Init(0,kTRUE);
  PlotFreezeOut();
  SetupFitType(kPCE165);
  Init(0,kTRUE);
  PlotFreezeOut();
}
Double_t *GetLims(TGraph *gr1, TGraph *gr2) {
  Double_t *yg1 = gr1->GetY();
  Double_t *yg2 = gr2->GetY();
  Double_t *rety = new Double_t[2];
  rety[0] = yg1[0];
  rety[1] = yg1[0];
  for(Int_t i=0;i<gr1->GetN();i++) {
    if(yg1[i]<rety[0]) rety[0] = yg1[i];
    if(yg2[i]<rety[0]) rety[0] = yg2[i];
    if(yg1[i]>rety[1]) rety[1] = yg1[i];
    if(yg2[i]>rety[1]) rety[1] = yg2[i];
  }
  return rety;
}
void DrawChiComparison(Int_t cbin1, Int_t cbin2) {
  SetupFitType(kCoarse);
  TGraph **grlow = GetChiSqVsTemp(cbin1,0.11,0.19,0.002);
  TGraph **grhigh = GetChiSqVsTemp(cbin2,0.11,0.19,0.002);
  TCanvas *c = BuildCanvasMatrix(1,2,300,450,0.15);
  TPad *top = (TPad*)c->FindObject("tp_0_0");
  top->cd();
  Double_t *topy = GetLims(grlow[0],grhigh[0]);
  Double_t *boty = GetLims(grlow[1],grhigh[1]);
  grlow[0]->SetLineColor(kRed+1);
  grlow[1]->SetLineColor(kRed+1);
  grhigh[0]->SetLineColor(kBlue+1);
  grhigh[1]->SetLineColor(kBlue+1);
  grlow[0]->SetLineWidth(3);
  grlow[1]->SetLineWidth(3);
  grhigh[0]->SetLineWidth(3);
  grhigh[1]->SetLineWidth(3);

  grlow[0]->Draw("AL");
  grlow[0]->GetYaxis()->SetRangeUser(topy[0]*0.9,topy[1]*1.1);
  grhigh[0]->Draw("SAME L");
  TLegend *leg = Legend(.42,.61,.72,.94);
  leg->AddEntry((TObject*)0x0,"Pb-Pb, 2.76 TeV","");
  leg->AddEntry(grlow[0],PbPbBins[cbin1],"L");
  leg->AddEntry(grhigh[0],PbPbBins[cbin2],"L");
  leg->Draw();
  top = (TPad*)c->FindObject("tp_0_1");
  top->cd();
  grlow[1]->Draw("AL");
  grlow[1]->GetYaxis()->SetRangeUser(boty[0]*0.9,boty[1]*1.1);
  grhigh[1]->Draw("SAME L");
  ProcessAxisPx(grlow[0]->GetYaxis(),25,0.01,30,1.5,509,0.02);
  ProcessAxisPx(grlow[1]->GetYaxis(),25,0.01,30,1.5,510,0.02);
  ProcessAxisPx(grlow[1]->GetXaxis(),25,0.01,30,1.9,510,0.02);
  grlow[0]->SetTitle(";;#chi^{2}/dof");
  grlow[1]->SetTitle(";#it{T}_{kin} (GeV);n");//#it{#beta}_{max}");//#LT#it{#beta}_{T}#GT");
}
void WriteContoursToFile(TString fileName, TString listName, TString listTitle="") {
  if(!lContours) {
    printf("Contours not calculated. You should rerun the whole thing after setting CalculateContours=kTRUE\n");
    return;
  }
  TFile *outFile = new TFile(fileName.Data(),"UPDATE");
  if(!listTitle.IsNull()) lContours->Add(new TNamed("Title",listTitle.Data()));
  lContours->Write(listName,TObject::kSingleKey+TObject::kOverwrite);
  outFile->Close();
}
