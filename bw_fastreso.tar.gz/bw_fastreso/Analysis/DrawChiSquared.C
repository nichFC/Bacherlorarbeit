#include "TFile.h"
#include "TH2D.h"
#include "Scripts/BuildCanvas.C"
#include "TGraph.h"
#include "TStyle.h"
#include "VarSetup.C"
#include "TMinuit.h"
#include "FitAll.C"
#include "TLatex.h"
#include "TPaletteAxis.h"

TFile *tf = new TFile("OtherOutput/PbPbPars.root");
TH2D *GetHist(Int_t cent) {
  if(!tf) {
    printf("File not opened!\n");
    return 0;
  };
  TH2D *rethist = (TH2D*)tf->Get(Form("FreeNorm_cent%i",cent));
  if(!rethist) {
    printf("Histogram FreeNorm_cent%i was not found in file %s\n",cent,tf->GetName());
    return 0;
  };
  rethist = (TH2D*)rethist->Clone(rethist->GetName());
  return rethist;
}
TGraph *GetGraph(Int_t cent) {
  if(!tf) {
    printf("File not opened!\n");
    return 0;
  };
  TGraph *rethist = (TGraph*)tf->Get(Form("FixedNorm_cent%i",cent));
  if(!rethist) {
    printf("Histogram FreeNorm_cent%i was not found in file %s\n",cent,tf->GetName());
    return 0;
  };
  //rethist = (TGraph*)rethist->Clone(rethist->GetName());
  return rethist;
}
TH2D *h2;
TGraph *gr;
TCanvas *DrawChiSquared(Int_t cent) {
  SetupVariables(kPbPb276);
  centr=cent;
  h2 = GetHist(centr);
  gr = GetGraph(centr);
  TCanvas *c = BuildSingleCanvas(400,600,0.1,0.15,0.1,0.1);
  gStyle->SetOptStat(0);
  h2->SetMaximum(6);
  h2->SetTitle(";#it{#beta}_{max};#it{T}_{fo}");
  h2->Draw("colz");
  h2->GetZaxis()->SetLabelFont(43);
  h2->GetZaxis()->SetLabelSize(25);
  ProcessAxisPx(h2->GetXaxis(),25,0.01,30,0,510,0.02);
  ProcessAxisPx(h2->GetYaxis(),25,0.01,30,0.8,508,0.02);
  gr->SetMarkerStyle(24);
  gr->SetMarkerSize(1.5);
  gr->Draw("SAME P");
  //fitting for the minimum
  TMinuit *mn = PerformFit(kFALSE,cent);
  Double_t tk,tke,bm,bme;
  mn->GetParameter(1,bm,bme);
  mn->GetParameter(2,tk,tke);
  TGraph *gr2 = new TGraph();
  gr2->SetPoint(0,bm,tk);
  gr2->SetMarkerStyle(20);
  gr2->SetMarkerSize(1.5);
  gr2->Draw("SAME P");
  TLegend *tleg = Legend(0,0.91,1,1);
  tleg->SetMargin(0.1);
  tleg->SetNColumns(3);
  tleg->AddEntry((TObject*)0x0,LegDesc.Data(),"");
  tleg->AddEntry(gr,"Fixed norm.","P");
  tleg->AddEntry(gr2,"Free norm.","P");
  tleg->Draw();
  c->Print(Form("../Figures/ChiSquared_PbPb_2D_Cent%i.pdf",cent));
  return c;
}
void DrawChiSquared() {
  SetupVariables(kPbPb276);
  for(Int_t i=0; i<nSpectraAA; i++) {
    TCanvas *c = DrawChiSquared(i);
    delete c;
  }
}
