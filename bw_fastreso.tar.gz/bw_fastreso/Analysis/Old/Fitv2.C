#include "TF1.h"
#include "TMath.h"
#include "TH3D.h"
#include "TFile.h"
#include "TGraphErrors.h"
#include "TMinuit.h"
#include "TCanvas.h"
#include "Scripts/BuildCanvas.C"
#include "Scripts/ProcessAxii.C"
#include "Scripts/Legend.C"
#include "Config.h"
inline double cs2FluiduM(double x) {
  return (x*x*(0.0010461910330715387 + x*(-0.016997351850612453 + x*(0.12595528994069613 + (-0.510477729039857 + x)*x)))*
     (3.831255349484765e-8 + x*(0.00002140058802480486 + x*(-0.00008693192041426982 + 
             x*(-0.018444802527704172 + x*(0.5368632648594895 + x*(-7.4522565817870365 + x*(62.30776783074574 + x*(-336.8744183413884 + x*(1191.026405027395 + x*(-2590.1225767072065 + 2712.1934046206975*x)))))))))
       ))/(7.313548422127797e-15 + x*(8.356306148115294e-12 + x*(2.3387986355395423e-9 + 
           x*(-6.605395132516945e-9 + x*(-1.790148526211301e-6 + x*(8.958041058260661e-6 + 
                    x*(0.0014381954623440515 + x*(-0.045458133957877116 + x*(0.726263758547687 + 
                             x*(-7.564793448616153 + x*(56.12131032495715 + x*(-308.4534327185232 + 
                                      x*(1271.3766801470479 + x*(-3884.3701789306033 + x*(8436.311867208919 + x*(-11805.768858200583 + 8136.580213862093*x))))))))))))))));
};


enum SystDesc {kpp7, kpp13, kpPb502, kPbPb276, kClosure};
SystDesc selsys = kPbPb276;
TString ConfigSF("");

const Int_t nBW=3;//3; //number of fit species
const Int_t nBWFit=3;
Bool_t UseTwoKernels=0;//kTRUE;
Bool_t SameNormForTwoKernels=0;//kTRUE;
Bool_t SameBetaForTwoKernels=0;//kTRUE;


const Double_t MPion = 0.13957018;
const Double_t MKaon = 0.497648;
const Double_t MProton = 0.938272;
const Double_t MXi = 1.3213;
Double_t masses[] = {MPion, MKaon, MProton,1.3,1.5};

Double_t rl[] = {0.2,0.2,0.2};//{0.5,0.5,0.5,0.5,0.5};//{0.5,0.5,0.5,0.7,1.3};//,0.5};//0.2,0.3};
Double_t rh[] = {3.,3.,3.};//{3.0,3.0,3,3.0,3.0};//1.5,3.0};

Int_t nSpectraAA=1;
Int_t centr = 0; //0-5, 5-10, 10-20, 20-40, 40-60, 60-80
TH3D *kernels[8][5];
const char *kpf[] = {"Keq1", "Keq2","Kshear1","Kshear2","Kshear3","Kshear4",
                      "Kbulk1","Kbulk2"};
TF1 **fBGBW;
TGraphErrors **gBW, *xi, *om;
TGraphErrors **gBWRat;
TString KernelFile("K_full_total.root");
//TString KernelFile("K_Tmax0.1550Tmin0.1050full_total_partial.root");
//TString KernelFile("K_Tmax0.1450Tmin0.0950full_total_partial.root");
const Double_t MHBARC = 0.19732697;


TString LegDesc="";
TString infile="";
TString ingrdesc="";
TString syspf="";
Int_t centLow=0;
Int_t centHigh=0;
const char *PbPbBins[] = {"0-5%","5-10%","10-20%","20-30%","30-40%","40-50%","50-60%","60-70%","70-80%","80-90%"};
const Int_t PbPbBinsInt[] = {0,5,10,20,30,40,50,60,70,80,90};
const char *pPbBins[] = {"0-5%","5-10%","10-20%","20-40%","40-60%","60-80%","80-100%"};
const Int_t pPbBinsInt[] = {0,5,10,20,40,60,80,100};
const char *ppBins[] = {"0-1%","1-5%","5-10%","10-15%","15-20%","20-30%","30-40%","40-50%","50-70%","70-100%"};
const Int_t ppBinsInt[] = {0,1,5,10,15,20,30,40,50,70,100};

TF1 *fBGBlastWave_Integrand1=0;
TF1 *fBGBlastWave_Integrand2=0;
void ReadConfig(TString ConfigFile) {
  FILE *infi = fopen(Form("Configs/%s",ConfigFile.Data()),"r");
  ConfigSF=ConfigFile.EqualTo("Nominal")?"":ConfigFile.Data();
  for(Int_t i=0;i<3;i++) fscanf(infi,"%lf %lf",&rl[i],&rh[i]);
  fclose(infi);
}
void SetupVariables(SystDesc insys) {
  switch(insys) {
    case kpp7:
      LegDesc = Form("pp, #sqrt{#it{s}} = 7 TeV, V0M %s",ppBins[centr]);
      syspf="pp7TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=10;
      centLow=ppBinsInt[centr];
      centHigh=ppBinsInt[centr+1];
      break;
    case kpp13:
      LegDesc = Form("pp, #sqrt{#it{s}} = 13 TeV, V0M %s",ppBins[centr]);
      syspf="pp13TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_V0MPct_%i_Sum";
      nSpectraAA=10;
      break;
    case kpPb502:
      LegDesc = Form("p-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV, V0M %s",pPbBins[centr]);
      syspf="pPb502TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=7;
      centLow=pPbBinsInt[centr];
      centHigh=pPbBinsInt[centr+1];
      break;
    case kPbPb276:
      LegDesc = Form("Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV, V0M %s",PbPbBins[centr]);
      syspf="PbPb276TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=10;
      centLow=PbPbBinsInt[centr];
      centHigh=PbPbBinsInt[centr+1];
      break;
    case kClosure:
      LegDesc = Form("Closure test");
      syspf="Closure";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=1;
      break;
    default:
      LegDesc = Form("Closure test");
      syspf="Closure";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=1;
      break;
  }
}
Double_t integrand_1(Double_t pt, Double_t beta_max, Double_t n, int massind, Double_t Tkin, Double_t etas,Double_t zetas, Double_t rmax, Double_t tmax, Double_t beta,Double_t  r)
{
  Double_t Keq1    = kernels[0][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear1 = kernels[2][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear3 = kernels[4][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kbulk1  = kernels[6][massind]->Interpolate(pt,beta,Tkin);
  // Speed of sound squared at freeze-out
  Double_t cs2=cs2FluiduM(Tkin);
  // Divergence of velocit D_mu u^mu in fm^-1
  Double_t theta = ( 1/TMath::Sqrt(1-beta*beta)/(1-cs2*beta*beta)*( (n+1)*beta/(r*rmax) + 1/tmax ) );
  Double_t bulkfactor =  MHBARC *1/(15*TMath::Power(1./3.-cs2,2))*zetas/Tkin;
  Double_t shearfactor =  MHBARC *etas/TMath::Power(Tkin,3);
  return Keq1  + bulkfactor*theta*Kbulk1 - shearfactor* ( 1/tmax/TMath::Sqrt(1-beta*beta)*Kshear1 + 1/(r*rmax)*beta/TMath::Sqrt(1-beta*beta)*Kshear3 -1.0/3.0 *(Kshear1+Kshear3)*theta );
}
Double_t integrand_2(Double_t pt, Double_t beta_max, Double_t m, int massind, Double_t Tkin, Double_t etas,Double_t zetas, Double_t rmax, Double_t tmax, Double_t beta,Double_t  t)
{
  Double_t Keq2    = kernels[1][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear2 = kernels[3][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kshear4 = kernels[5][massind]->Interpolate(pt,beta,Tkin);
  Double_t Kbulk2  = kernels[7][massind]->Interpolate(pt,beta,Tkin);
  // Speed of sound squared at freeze-out

  Double_t cs2=cs2FluiduM(Tkin);
  // Divergence of velocit D_mu u^mu in fm^-1
  Double_t theta = ( 1/TMath::Sqrt(1-beta*beta)/(1-cs2*beta*beta)*( (m+1)*beta/(rmax) + 1/(t*tmax) ) ); // because of integration add factor of 2 to 1/tau
  Double_t bulkfactor =  MHBARC *1/(15*TMath::Power(1./3.-cs2,2))*zetas/Tkin;
  Double_t shearfactor =  MHBARC *etas/TMath::Power(Tkin,3);
  return Keq2 + bulkfactor*theta*Kbulk2 - shearfactor* ( 1/(t*tmax)/TMath::Sqrt(1-beta*beta)*Kshear2 + 1/(rmax)*beta/TMath::Sqrt(1-beta*beta)*Kshear4 -1.0/3.0 *(Kshear2+Kshear4)*theta );
}

Double_t BGBlastWave_Integrand1(const Double_t *x, const Double_t *p)
{
  /*
     x[0] -> r (radius)
     p[0] -> pT (transverse momentum)
     p[1] -> beta_max (surface velocity)
     p[2] -> T (freezout temperature)
     p[3] -> n (velocity profile)
     p[4] -> massInd (particle specie)
  */
  Double_t r = x[0];
  Double_t pt = p[0];
  Double_t beta_max = p[1];
  Int_t massind = TMath::Nint(p[4]);
  //  Double_t temp_1 = 1. / p[3];
  Double_t n = p[3];
  Double_t beta = beta_max * TMath::Power(r, n);
  Double_t Tkin = p[2];
  Double_t rmax = p[5];
  Double_t tmax = p[6];
  Double_t etas = p[7];
  Double_t zetas = p[8];
  Int_t ptind = kernels[0][massind]->GetXaxis()->FindBin(pt);
  Int_t betai = kernels[0][massind]->GetYaxis()->FindBin(beta);
  Int_t tempind = kernels[0][massind]->GetZaxis()->FindBin(Tkin);

  //printf("Attempting to evaluate kernel at (%f, %f, %f)\n",pt,beta,p[3]*1000);
  if(!kernels[0][0]) printf("Could not fetch kernels!\n");
  Double_t ker;
  /*Double_t mt=TMath::Sqrt(pt*pt+masses[massind]*masses[massind]);
  Double_t temp_1 = 1./Tkin;
  Double_t rho = TMath::ATanH(beta);
  Double_t argI0 = pt * TMath::SinH(rho) * temp_1;
  if (argI0 > 700.) argI0 = 700.;
  Double_t argK1 = mt * TMath::CosH(rho) * temp_1;
  //  if (argI0 > 100 || argI0 < -100)
  //    printf("r=%f, pt=%f, beta_max=%f, temp=%f, n=%f, mt=%f, beta=%f, rho=%f, argI0=%f, argK1=%f\n", r, pt, beta_max, 1. / temp_1, n, mt, beta, rho, argI0, argK1);
  ker = TMath::TwoPi()*2* mt * TMath::BesselI0(argI0) * TMath::BesselK1(argK1);
  if(massind==2) ker=ker*2;*/

  //printf("Interpolating at %f %f %f\n",pt,beta,Tkin);

//  ker = kernels[0][massind]->Interpolate(pt,beta,Tkin);
  return r * integrand_1(pt, beta_max, n, massind, Tkin, etas,zetas, rmax, tmax, beta, r);
};

Double_t BGBlastWave_Integrand2(const Double_t *x, const Double_t *p)
{
  /*
     x[0] -> r (radius)
     p[0] -> pT (transverse momentum)
     p[1] -> beta_max (surface velocity)
     p[2] -> T (freezout temperature)
     p[3] -> n (velocity profile)
     p[4] -> massInd (particle specie)
  */
  Double_t t = x[0];
  Double_t pt = p[0];
  Double_t beta_max = p[1];
  Int_t massind = TMath::Nint(p[4]);
  //  Double_t temp_1 = 1. / p[3];
  Double_t m = p[3];
  Double_t beta = beta_max * TMath::Power(t, m);
  Double_t Tkin = p[2];
  Double_t rmax = p[5];
  Double_t tmax = p[6];
  Double_t etas = p[7];
  Double_t zetas = p[8];
  Int_t ptind = kernels[0][massind]->GetXaxis()->FindBin(pt);
  Int_t betai = kernels[0][massind]->GetYaxis()->FindBin(beta);
  Int_t tempind = kernels[0][massind]->GetZaxis()->FindBin(Tkin);

  //printf("Attempting to evaluate kernel at (%f, %f, %f)\n",pt,beta,p[3]*1000);
  if(!kernels[0][0]) printf("Could not fetch kernels!\n");
  Double_t ker;
  return t * integrand_2(pt, beta_max, m, massind, Tkin, etas,zetas, rmax, tmax, beta, t);
};


Double_t
BGBlastWave_Func_OneOverPt(const Double_t *x, const Double_t *p)
{
  Double_t pt = x[0];
  Double_t massInd = p[0];
  Double_t beta_max = p[1];
  Double_t temp = p[2];
  Double_t n = p[3];
  Double_t m = p[4];
  Double_t rmax = p[5];
  Double_t tmax = p[6];
  Double_t etas = p[7];
  Double_t zetas = p[8];
 rmax = tmax;
  Int_t IntmIND = TMath::Nint(massInd);
  //if(pt<rl[IntmIND] || pt > rh[IntmIND]) return 0;
  if (!fBGBlastWave_Integrand1)
    fBGBlastWave_Integrand1 = new TF1("fBGBlastWave_Integrand1", BGBlastWave_Integrand1, 0., 1., 9);
//  if (!fBGBlastWave_Integrand2)
//    fBGBlastWave_Integrand2 = new TF1("fBGBlastWave_Integrand2", BGBlastWave_Integrand2, 0., 1., 9);
  Double_t prs[] = {pt,beta_max,temp,n,massInd,rmax,tmax,etas,zetas};
  fBGBlastWave_Integrand1->SetParameters(pt, beta_max, temp, n, massInd,rmax,tmax,etas,zetas);
//  fBGBlastWave_Integrand2->SetParameters(pt, beta_max, temp, m, massInd,rmax,tmax,etas,zetas);
  Double_t integral1 = fBGBlastWave_Integrand1->Integral(0., 1., 1e-3);//GetSSFromBeta(beta_max));
//  Double_t integral2 = fBGBlastWave_Integrand2->Integral(0., 1., 1e-3);//GetSSFromBeta(beta_max));
  return  rmax*tmax/TMath::Power(2*M_PI*MHBARC,3)*(  rmax*integral1 ); //+ tmax*integral2 ); 
};

void
BGBlastWave_FCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{

  // beta -> beta_max
  Double_t beta_max = par[1];
  Double_t T = par[2];
  Double_t n = par[3];
  Double_t m = par[0];
  Double_t rmax = par[4];
  Double_t tmax = par[5];
  Double_t etas = par[6];
  Double_t zetas = par[7];

  //Double_t beta_max = 0.5 * (2. + n) * beta;
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  // loop over all the data
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    // set BGBW parameters
    fBGBW[iBW]->SetParameter(0,iBW*1.0);
    fBGBW[iBW]->SetParameter(1, beta_max);
    fBGBW[iBW]->SetParameter(2, T);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(4, par[0]);
    for(Int_t i=5;i<9;++i) fBGBW[iBW]->SetParameter(i,par[i-1]);
    if(iBW>=nBWFit) continue;
    // loop over all the points
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(pt<rl[iBW] || pt>rh[iBW]) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  f = chi;
};
TGraphErrors *HtoGr(TH1 *inh, Double_t ptlow, Double_t pthigh) {
  TGraphErrors *retgr = new TGraphErrors();
  Int_t pcount = 0;
  for(Int_t i=inh->FindBin(ptlow+1e-6); i<=inh->FindBin(pthigh-1e-6); i++) {
    retgr->SetPoint(pcount,inh->GetBinCenter(i),inh->GetBinContent(i));
    retgr->SetPointError(pcount,inh->GetBinWidth(i)/2,inh->GetBinError(i));
    pcount++;
  };
  return retgr;
};
TGraphErrors *HtoGr(TH1 *inh) {
  Double_t ptlow = inh->GetBinCenter(1);
  Double_t pthigh = inh->GetBinCenter(inh->GetNbinsX());
  return HtoGr(inh,ptlow,pthigh);
};
TGraphErrors *MakeRatio(TGraphErrors *ingr, TF1 *inf, Bool_t Debug=kFALSE) {
  TGraphErrors *retgr = new TGraphErrors();
  Double_t x,y,xe,ye;
  for(Int_t i=0;i<ingr->GetN(); i++) {
    ingr->GetPoint(i,x,y);
    if(x>5) break;
    if(x<0.5) continue;
    xe = ingr->GetErrorX(i);
    ye = ingr->GetErrorY(i);
    Int_t np = retgr->GetN();
    retgr->SetPoint(np,x,y/inf->Eval(x));
    if(Debug) printf("Debug: x(%f), y(%f) vs. function y(%f)\n",x,y,inf->Eval(x));
    retgr->SetPointError(np,xe,ye/inf->Eval(x));
  };
  return retgr;
};
void PreloadSpectra() {
  TFile *tf = new TFile(infile.Data(),"READ");
  const char *pikpnames[] = {"pi","ka","pr"};
  gBW = new TGraphErrors*[nBW];
  for(Int_t i=0;i<3;i++) gBW[i] = (TGraphErrors*)tf->Get(Form(ingrdesc.Data(),pikpnames[i],centr));
  tf->Close();
}
void Init() {
  SetupVariables(selsys);
  PreloadSpectra();
  if(!kernels[0][0]) {
    //kernels = new TH3D**[7];
    //for(Int_t i=0;i<5;i++) kernels[i] = new TH3D*[5];
//    kernels = new TH3D*[7][5];
    const char *nams[] = {"pi0139plu","Ka0492plu","pr0938plu","Xi1321min","UM1672min"};//{"pions","kaons","protons","Xi","Om"};
    TFile *tf = new TFile(KernelFile.Data(),"READ");
    for(Int_t j=0;j<8;j++) {
      for(Int_t i=0;i<3;i++) {
        printf("Reading %s..\n",Form("%s_%s",nams[i],kpf[j]));
        kernels[j][i] = (TH3D*)tf->Get(Form("%s_%s",nams[i],kpf[j]));
        if(!kernels[j][i]) printf("Could not read find in file %s!\n",tf->GetTitle());
        else printf("Cloning...\n");
        kernels[j][i] = (TH3D*)kernels[j][i]->Clone(Form("%s_%s",nams[i],kpf[j]));
        printf("Done!\n");
        kernels[j][i]->SetDirectory(0);
      };
    };
    tf->Close();
  };
  fBGBW = new TF1*[nBW];
  for(Int_t i=0;i<nBW;i++) fBGBW[i] = new TF1(Form("BGBW_%i",i),BGBlastWave_Func_OneOverPt,0.2,3,9);
};
TMinuit* PerformFit(Bool_t DrawFit=kFALSE, Int_t l_cent=-1) {
  if(l_cent>-1) centr=l_cent;
  Init();
  TMinuit *minuit = new TMinuit(8);
  minuit->SetFCN(BGBlastWave_FCN);
  Double_t arglist[10];
  Int_t ierflg = 0;
  arglist[0] = 1;
  minuit->mnexcm("SET ERR", arglist, 1, ierflg);
  Double_t norms[] = {2770,1940,800,10,10};
  minuit->mnparm(0, "m", 1, 0.01, 0.01, 5., ierflg);
  minuit->mnparm(1, "beta_max", 0.8, 0.01, 0.1, 0.985, ierflg);
  minuit->mnparm(2, "T", 0.155, 0.001, 0.130, 0.175, ierflg);
  minuit->mnparm(3, "n", 1., 0.01, 0.01, 5., ierflg);
  minuit->mnparm(4, "rmax",12,0.5,0,50, ierflg);
  minuit->mnparm(5, "tmax",10,0.5,0,50, ierflg);
  minuit->mnparm(6, "etas", 0.0, 0.01,-5,5, ierflg);
  minuit->mnparm(7, "zetas", 0.0, 0.01, -5, 5, ierflg);
  
  // Fixed parameters
  minuit->FixParameter(0);
  minuit->FixParameter(4);
  //minuit->FixParameter(6);
  //minuit->FixParameter(7);
  arglist[0] = 1;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n First MIGRAD ierflg: %i\n\n\n",ierflg);

  /* set strategy */
  arglist[0] = 2;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  printf("\n\n\n Set Strategy ierflg: %i\n\n\n",ierflg);

  //UseInterpolated=kTRUE;

  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n Second ierflg: %i\n\n\n",ierflg);


  /* start IMPROVE minimization */
  //arglist[0] = 500000;
  minuit->mnexcm("IMPROVE", arglist, 1, ierflg);
  printf("\n\n\n IMPROVE ierflg: %i\n\n\n",ierflg);
  //return minuit;
  /* start MINOS */
  arglist[0] = 500000;
  arglist[1] = 1;
  arglist[2] = 2;
  arglist[3] = 3;
  arglist[4] = 4;
  arglist[5] = 5;
  arglist[6] = 6;
  arglist[7] = 7;
  minuit->mnexcm("MINOS", arglist, 4, ierflg);
  Double_t amin,edm,errdef;
  Int_t nvpar,nparx,icstat;
  minuit->mnstat(amin, edm, errdef, nvpar, nparx, icstat);
  minuit->mnprin(8, amin);

  Int_t degrees_of_freedom=0; 
  for(Int_t i=0;i<nBW;i++) {
  for (Int_t ipt = 0; ipt < gBW[i]->GetN(); ipt++) {
      Double_t pt = gBW[i]->GetX()[ipt];
      if(rl[i] > pt || rh[i]<pt) continue;
      degrees_of_freedom++;
    }
  }

  printf("Number of degrees of freedom: %d\n",degrees_of_freedom);


  if(!DrawFit) return minuit;
  gBWRat = new TGraphErrors*[nBW];
  TCanvas *c = BuildSpagethiCanvas(4);
  TPad *tp;
  Int_t cols[] = {kRed+1, kBlue+1, kGreen+2, kMagenta+2, kBlack};
  Double_t ymin,ymax,trash;
  TLegend *leg = Legend(.396411,.58435,.941272,.885085);
  leg->AddEntry((TObject*)0x0,LegDesc.Data(), "");
  const char *snams[] = {"#pi^{#pm}","K^{#pm}","p+#bar{p}"};
  for(Int_t i=0;i<nBW;i++) {
      tp = (TPad*)c->FindObject("tp_0");
    tp->cd();
    gBW[i]->Draw(i?"SAME P":"AP");
    gBW[i]->GetXaxis()->SetRangeUser(0,4.5);
    if(!i) {
      gBW[0]->GetPoint(0,trash,ymax);
      ymin = gBW[2]->Eval(3);
      gBW[0]->GetYaxis()->SetRangeUser(0.8*ymin,1.2*ymax);
      printf("Y ranges: %f to %f\n",ymin,ymax);
    };
    ProcessAxisPx(gBW[i]->GetYaxis(),25,0.005,30,2.2,510,0.01);
    gBW[i]->GetYaxis()->SetTitle("#frac{1}{#it{N}_{ev}}#frac{1}{2#pi#it{p}_{T}}#frac{d^{2}#it{N}}{d#it{y}d#it{p}_{T}} [GeV^{2}]");
    if(!i) {
      tp->SetLogy();
    };
    gBW[i]->SetLineColor(cols[i]);
    leg->AddEntry(gBW[i],snams[i],"L");
    if(i==2) leg->Draw();
    fBGBW[i]->SetLineColor(cols[i]);
    fBGBW[i]->SetRange(0.1,4.5);
    fBGBW[i]->Draw("SAME L");
    tp = (TPad*)c->FindObject(Form("tp_%i",i+1));
    tp->cd();
    gBWRat[i] = MakeRatio(gBW[i],fBGBW[i]);
    gBWRat[i]->GetYaxis()->SetLabelSize(0.15);
    gBWRat[i]->GetYaxis()->SetNdivisions(505);
    gBWRat[i]->SetLineColor(cols[i]);
    gBWRat[i]->GetYaxis()->SetRangeUser(0.5,1.5);
    gBWRat[i]->GetXaxis()->SetRangeUser(0,4.5);
    gBWRat[i]->Draw("AP");
    gBWRat[i]->SetTitle(";#it{p}_{T} [GeV/#it{c}]; Data/Fit");
    ProcessAxisPx(gBWRat[i]->GetYaxis(),25,0.005,30,2.2,505,0.02);
    ProcessAxisPx(gBWRat[i]->GetXaxis(),25,0.005,30,2.5,506,0.02);
  };
  const char *sf="";
  if(nSpectraAA!=1) {
    if(!centr) sf="(";
    if(centr==nSpectraAA-1)
      sf=")";
    };
  c->Print(Form("Output/SpectraComp/%s%s.pdf%s",syspf.Data(),ConfigSF.Data(),sf));
  return minuit;
};
Double_t CalculateChiSquared(Double_t beta1, Double_t Tkin, Double_t norm1, Double_t n) {
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    // set BGBW parameters
    fBGBW[iBW]->SetParameter(0, iBW*1.0);
    fBGBW[iBW]->SetParameter(1, beta1);
    fBGBW[iBW]->SetParameter(2, Tkin);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(4, norm1);
    // loop over all the points
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(rl[iBW] > pt || rh[iBW]<pt) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  return chi;
};
void PlotFreezeOut(Bool_t DrawPerformance=kFALSE) {
  TGraphErrors *gr = new TGraphErrors();
  FILE *outputpars = fopen(Form("Output/FitParameters/%s.txt",syspf.Data()),"a+");
  TString fixedpars("");
  if(UseTwoKernels) {
    fixedpars.Append("Two kernels used (N2, B2). ");
    if(SameNormForTwoKernels || SameBetaForTwoKernels) fixedpars.Append("Fixed pars: ");
    if(SameNormForTwoKernels) fixedpars.Append("N2=N1 ");
    if(SameBetaForTwoKernels) fixedpars.Append("B2=B1 ");
  } else fixedpars.Append("Single kernel ");
  fprintf(outputpars,"\n\n#%s, fit pions[%1.1f-%1.1f], kaons [%1.1f-%1.1f], protons [%1.1f-%1.1f]. %s\n",
	  syspf.Data(),rl[0],rh[0],rl[1],rh[1],rl[2],rh[2],fixedpars.Data());
  fprintf(outputpars,"#Cmin\tCmax\tN1\t\tN1er\t\tBeta1\t\tBeta1err\tT\t\tTerr\t\tn\t\tnerr");//\tchisq\n");
  if(UseTwoKernels) {
    if(!SameNormForTwoKernels) fprintf(outputpars,"\t\tN2\t\tN2err");
    if(!SameBetaForTwoKernels) fprintf(outputpars,"\t\tB2\t\tB2err");
  };
  fprintf(outputpars,"\t\tChiSq\n");
  gr->SetPoint(0,0,0);
  for(Int_t i=0;i<nSpectraAA;i++) {
    centr=i;
    Init();
    TMinuit *mn = PerformFit(DrawPerformance);
    Double_t b1,tk,b1e,tke,n,ne,n1,n1e, n2,n2e,b2,b2e;
    mn->GetParameter(0,n1,n1e);
    mn->GetParameter(1,b1,b1e);
    mn->GetParameter(2,tk,tke);
    mn->GetParameter(3,n,ne);
    if(UseTwoKernels) {
      mn->GetParameter(4,n2,n2e);
      mn->GetParameter(5,b2,b2e);
    } else {
      n2=0;
      b2=0;
    };
    Double_t chisq = CalculateChiSquared(b1,tk,n1,n);
    Int_t np = gr->GetN();
    gr->SetPoint(np,b1/(0.5*(2+n)),tk);
    gr->SetPointError(np,b1e/(0.5*(2+n)),tke);
    fprintf(outputpars,"%i\t%i\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e",centLow,centHigh,
	    n1,n1e,b1,b1e,tk,tke,n,ne);
    if(UseTwoKernels) {
      if(!SameNormForTwoKernels) fprintf(outputpars,"\t%4.4e\t%4.4e",n2,n2e);
      if(!SameBetaForTwoKernels) fprintf(outputpars,"\t%4.4e\t%4.4e",b2,b2e);
    };
    fprintf(outputpars,"\t%4.4e\n",chisq);
  };
  Int_t np=gr->GetN();
  gr->SetPoint(np,1,0.2);
  fclose(outputpars);
  gr->SetTitle(";#LT#beta_{T}#GT;T_{kin}");
  TCanvas *c = new TCanvas("tkin","tkin",600,600);
  gr->Draw("AP");
  gr->SetName(Form("%s%s",syspf.Data(),ConfigSF.Data()));

  TFile *tf = new TFile(Form("Output/BetaT/%s.root",syspf.Data()),"UPDATE");
  gr->Write(0,TObject::kOverwrite);
  tf->Close();
};
void PlotAll(TString configname) {
  ReadConfig(configname);
  selsys=kpp7;
  PlotFreezeOut(kTRUE);
  selsys=kPbPb276;
  PlotFreezeOut(kTRUE);
  selsys=kpPb502;
  PlotFreezeOut(kTRUE);
}
void PlotAll(){
  PlotAll("Nominal");
  //PlotAll("Original");
  //PlotAll("LowPt");
  //PlotAll("HighPt");
}
