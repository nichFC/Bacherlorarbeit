#include "TF1.h"
#include "TMath.h"
#include "TH3D.h"
#include "TFile.h"
#include "TGraphErrors.h"
#include "TMinuit.h"
#include "TCanvas.h"
#include "Scripts/BuildCanvas.C"
#include "Scripts/ProcessAxii.C"
//#include "Scripts/Legend.C"
#include "Config.h"
#include "TList.h"
#include "VarSetup.C"

Bool_t CalculateContours=kTRUE;
const Int_t nBWFit=3;//number of fitting species


const Double_t MPion = 0.13957018;
const Double_t MKaon = 0.497648;
const Double_t MProton = 0.938272;
const Double_t MK0s = 0.497611;
const Double_t MXi = 1.3213;
Double_t masses[] = {MPion, MKaon, MProton,1.3,1.5};


TH3D **kernels=NULL;
TF1 **fBGBW;
TGraphErrors **gBW, *xi, *om;
TGraphErrors **gBWRat;
TString KernelFile("Kernels20190308/Keq12_total.root");
TList *lContours=0;


void ResetContours();
void RescaleContourToMeanBeta(TGraph*,Double_t);
TF1 *fBGBlastWave_Integrand=0;



Double_t BGBlastWave_Integrand(const Double_t *x, const Double_t *p)
{

  /*
     x[0] -> r (radius)
     p[0] -> pT (transverse momentum)
     p[1] -> beta_max (surface velocity)
     p[2] -> T (freezout temperature)
     p[3] -> n (velocity profile)
     p[4] -> massInd (particle specie)
  */

  Double_t r = x[0];
  Double_t pt = p[0];
  Double_t beta_max = p[1];
  Int_t massind = TMath::Nint(p[4]);
  //  Double_t temp_1 = 1. / p[3];
  Double_t n = p[3];
  Double_t beta = beta_max * TMath::Power(r, n);
  Double_t Tkin = p[2];

  Int_t ptind = kernels[massind]->GetXaxis()->FindBin(pt);
  Int_t betai = kernels[massind]->GetYaxis()->FindBin(beta);
  Int_t tempind = kernels[massind]->GetZaxis()->FindBin(Tkin);

  //printf("Attempting to evaluate kernel at (%f, %f, %f)\n",pt,beta,p[3]*1000);
  if(!kernels) printf("Could not fetch kernels!\n");
  Double_t ker;
  /*Double_t mt=TMath::Sqrt(pt*pt+masses[massind]*masses[massind]);
  Double_t temp_1 = 1./Tkin;
  Double_t rho = TMath::ATanH(beta);
  Double_t argI0 = pt * TMath::SinH(rho) * temp_1;
  if (argI0 > 700.) argI0 = 700.;
  Double_t argK1 = mt * TMath::CosH(rho) * temp_1;
  //  if (argI0 > 100 || argI0 < -100)
  //    printf("r=%f, pt=%f, beta_max=%f, temp=%f, n=%f, mt=%f, beta=%f, rho=%f, argI0=%f, argK1=%f\n", r, pt, beta_max, 1. / temp_1, n, mt, beta, rho, argI0, argK1);
  ker = TMath::TwoPi()*2* mt * TMath::BesselI0(argI0) * TMath::BesselK1(argK1);
  if(massind==2) ker=ker*2;*/

  //printf("Interpolating at %f %f %f\n",pt,beta,Tkin);

  ker = kernels[massind]->Interpolate(pt,beta,Tkin);
  return r * ker;
};

Double_t
BGBlastWave_Func_OneOverPt(const Double_t *x, const Double_t *p)
{
  Double_t pt = x[0];
  Double_t massInd = p[0];
  Double_t beta_max = p[1];
  Double_t temp = p[2];
  Double_t n = p[3];
  Double_t norm = p[4];
  Int_t IntmIND = TMath::Nint(massInd);
  //if(pt<rl[IntmIND] || pt > rh[IntmIND]) return 0;
  if (!fBGBlastWave_Integrand)
    fBGBlastWave_Integrand = new TF1("fBGBlastWave_Integrand", BGBlastWave_Integrand, 0., 1., 5);
  Double_t prs[] = {pt,beta_max,temp,n,massInd};
  fBGBlastWave_Integrand->SetParameters(pt, beta_max, temp, n, massInd);
  Double_t integral = fBGBlastWave_Integrand->Integral(0., 1., 1e-3);//GetSSFromBeta(beta_max));
  return norm * integral;
};

void
BGBlastWave_FCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{

  // beta -> beta_max
  Double_t beta_max = par[1];
  Double_t T = par[2];
  Double_t n = par[3];
  //Double_t beta_max = 0.5 * (2. + n) * beta;
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  // loop over all the data
  for (Int_t iBW = 0; iBW < nBWFit; iBW++) {
    // set BGBW parameters
    fBGBW[iBW]->SetParameter(0,iBW*1.0);
    fBGBW[iBW]->SetParameter(1, beta_max);
    fBGBW[iBW]->SetParameter(2, T);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(4, par[0]);
    if(iBW>=nBWFit) continue;
    // loop over all the points
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(pt<rl[iBW] || pt>rh[iBW]) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  f = chi;
};
TGraphErrors *HtoGr(TH1 *inh, Double_t ptlow, Double_t pthigh) {
  TGraphErrors *retgr = new TGraphErrors();
  Int_t pcount = 0;
  for(Int_t i=inh->FindBin(ptlow+1e-6); i<=inh->FindBin(pthigh-1e-6); i++) {
    retgr->SetPoint(pcount,inh->GetBinCenter(i),inh->GetBinContent(i));
    retgr->SetPointError(pcount,inh->GetBinWidth(i)/2,inh->GetBinError(i));
    pcount++;
  };
  return retgr;
};
TGraphErrors *HtoGr(TH1 *inh) {
  Double_t ptlow = inh->GetBinCenter(1);
  Double_t pthigh = inh->GetBinCenter(inh->GetNbinsX());
  return HtoGr(inh,ptlow,pthigh);
};
TGraphErrors *MakeRatio(TGraphErrors *ingr, TF1 *inf, Bool_t Debug=kFALSE) {
  TGraphErrors *retgr = new TGraphErrors();
  Double_t x,y,xe,ye;
  for(Int_t i=0;i<ingr->GetN(); i++) {
    ingr->GetPoint(i,x,y);
    if(x>5) break;
    if(x<0.5) continue;
    xe = ingr->GetErrorX(i);
    ye = ingr->GetErrorY(i);
    Int_t np = retgr->GetN();
    retgr->SetPoint(np,x,y/inf->Eval(x));
    if(Debug) printf("Debug: x(%f), y(%f) vs. function y(%f)\n",x,y,inf->Eval(x));
    retgr->SetPointError(np,xe,ye/inf->Eval(x));
  };
  return retgr;
};
void PreloadSpectra(Int_t cent) {
  TFile *tf = new TFile(infile.Data(),"READ");
  const char *pikpnames[] = {"pi","ka","pr","Lambda","Xi","Omega"};
  nBW=GetNBW(cent);
  gBW = new TGraphErrors*[nBW];
  for(Int_t i=0;i<nBW;i++) gBW[i] = (TGraphErrors*)tf->Get(Form(ingrdesc.Data(),pikpnames[i],centr));
  tf->Close();
}
void Init(Int_t cent) {
  SetupVariables(selsys);
  PreloadSpectra(cent);
  if(!kernels) {
    kernels = new TH3D*[6];
    const char *nams[] = {"pi0139plu","Ka0492plu","pr0938plu","Lm1115zer","Xi1321min","UM1672min"};//{"pions","kaons","protons","Xi","Om"};
    TFile *tf = new TFile(KernelFile.Data(),"READ");
    for(Int_t i=0;i<6;i++) {
      kernels[i] = (TH3D*)tf->Get(Form("%s_Keq1",nams[i]))->Clone(Form("%s_Keq1",nams[i]));
      kernels[i]->SetDirectory(0);
    };
    tf->Close();
  };
  fBGBW = new TF1*[nBW];
  for(Int_t i=0;i<nBW;i++) fBGBW[i] = new TF1(Form("BGBW_%i",i),BGBlastWave_Func_OneOverPt,0.2,3,5);
};
void CopyParsToBW(TMinuit *mn) {
  Double_t beta, tkin, expo, norm, trash;
  mn->GetParameter(0,norm,trash);
  mn->GetParameter(1,beta,trash);
  mn->GetParameter(2,tkin,trash);
  mn->GetParameter(3,expo,trash);
  for(Int_t i=0;i<nBW;i++)
    fBGBW[i]->SetParameters(i,beta,tkin,expo,norm);
}

TMinuit* PerformFit(Bool_t DrawFit=kFALSE, Int_t l_cent=-1) {
  if(l_cent>-1) centr=l_cent;
  Init(l_cent);
  TMinuit *minuit = new TMinuit(6);
  minuit->SetFCN(BGBlastWave_FCN);
  Double_t arglist[10];
  Int_t ierflg = 0;
  arglist[0] = 1;
  minuit->mnexcm("SET ERR", arglist, 1, ierflg);
  Double_t norms[] = {1770,1940,800,10,10};
  minuit->mnparm(0, "Norm_K1", 400, 10., 1., 1600., ierflg);
  minuit->mnparm(1, "beta_max", 0.6, 0.01, 0.1, 0.985, ierflg);
  minuit->mnparm(2, "T", 0.140, 0.001, 0.131, 0.179, ierflg);
  minuit->mnparm(3, "n", 1, 0.01, 0.1, 10., ierflg);
  //minuit->FixParameter(3);

  arglist[0] = 1;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n First MIGRAD ierflg: %i\n\n\n",ierflg);

  /* set strategy */
  arglist[0] = 2;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  printf("\n\n\n Set Strategy ierflg: %i\n\n\n",ierflg);

  //UseInterpolated=kTRUE;

  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n Second ierflg: %i\n\n\n",ierflg);


  /* start IMPROVE minimization */
  //arglist[0] = 500000;
  minuit->mnexcm("IMPROVE", arglist, 1, ierflg);
  printf("\n\n\n IMPROVE ierflg: %i\n\n\n",ierflg);

  /* start MINOS */
  arglist[0] = 500000;
  arglist[1] = 0;
  arglist[2] = 1;
  arglist[3] = 2;
  arglist[4] = 3;
  minuit->mnexcm("MINOS", arglist, 4, ierflg);
  Double_t amin,edm,errdef;
  Int_t nvpar,nparx,icstat;
  minuit->mnstat(amin, edm, errdef, nvpar, nparx, icstat);
  minuit->mnprin(4, amin);
  if(CalculateContours) {
    minuit->SetErrorDef(1);
    //Limit nmax, otherwise, can't calculate proper contours in some cases
    Double_t nval, nerr, nvalr;
    minuit->GetParameter(3,nval,nerr);
    nvalr=nval+5.5;
    TGraph *grc=0;
    while(!grc) { //While no grc
        nvalr-=0.5;
        if(nvalr<nval) break; //In case max goes below original value, break
        minuit->mnparm(3, "n", 1, 0.01, 0.1, nvalr, ierflg);
        grc = (TGraph*)minuit->Contour(80,1,2);
        //If graph is less than 80 points, delete it
        //One could have grc->GetN()<80 in the while condition,
        //but then the problem is that sometimes no graph is returned
        //and thus one can't check N
        if(grc) if(grc->GetN()<80) {
          delete grc;
          grc=0;
        };
    };
    if(grc) {
      grc->SetName(Form("%sContour_%i",syspf.Data(),centr));
      RescaleContourToMeanBeta(grc,nval);
      if(!lContours) ResetContours();
      lContours->Add(grc);
    } else printf("Could not calculate contour for %s, centrality %i\n",syspf.Data(),centr);
  }

  CopyParsToBW(minuit);
  if(!DrawFit) return minuit;
  gBWRat = new TGraphErrors*[nBW];
  TCanvas *c = BuildSpagethiCanvas(4);
  TPad *tp;
  Int_t cols[] = {kRed+1, kBlue+1, kGreen+2, kMagenta+2, kBlack};
  Double_t ymin,ymax,trash;
  TLegend *leg = Legend(.396411,.58435,.941272,.885085);
  leg->AddEntry((TObject*)0x0,LegDesc.Data(), "");
  const char *snams[] = {"#pi^{#pm}","K^{#pm}","p+#bar{p}"};
  for(Int_t i=0;i<nBW;i++) {
    tp = (TPad*)c->FindObject("tp_0");
    tp->cd();
    gBW[i]->Draw(i?"SAME P":"AP");
    gBW[i]->GetXaxis()->SetRangeUser(0,3);
    if(!i) {
      gBW[0]->GetPoint(0,trash,ymax);
      ymin = gBW[2]->Eval(3);
      gBW[0]->GetYaxis()->SetRangeUser(0.8*ymin,1.2*ymax);
      printf("Y ranges: %f to %f\n",ymin,ymax);
    };
    ProcessAxisPx(gBW[i]->GetYaxis(),25,0.005,30,2.2,510,0.01);
    gBW[i]->GetYaxis()->SetTitle("#frac{1}{#it{N}_{ev}}#frac{1}{2#pi#it{p}_{T}}#frac{d^{2}#it{N}}{d#it{y}d#it{p}_{T}} [GeV^{2}]");
    if(!i) {
      tp->SetLogy();
    };
    gBW[i]->SetLineColor(cols[i]);
    leg->AddEntry(gBW[i],snams[i],"L");
    if(i==2) leg->Draw();
    fBGBW[i]->SetLineColor(cols[i]);
    fBGBW[i]->SetRange(0.2,3);
    fBGBW[i]->Draw("SAME L");
    tp = (TPad*)c->FindObject(Form("tp_%i",i+1));
    tp->cd();
    gBWRat[i] = MakeRatio(gBW[i],fBGBW[i]);
    gBWRat[i]->GetYaxis()->SetLabelSize(0.15);
    gBWRat[i]->GetYaxis()->SetNdivisions(505);
    gBWRat[i]->SetLineColor(cols[i]);
    gBWRat[i]->GetYaxis()->SetRangeUser(0.,2.);
    gBWRat[i]->GetXaxis()->SetRangeUser(0,3);
    gBWRat[i]->Draw("AP");
    gBWRat[i]->SetTitle(";#it{p}_{T} [GeV/#it{c}]; Data/Fit");
    ProcessAxisPx(gBWRat[i]->GetYaxis(),25,0.005,30,2.2,505,0.02);
    ProcessAxisPx(gBWRat[i]->GetXaxis(),25,0.005,30,2.5,506,0.02);
  };
  const char *sf="";
  if(nSpectraAA!=1) {
    if(!centr) sf="(";
    if(centr==nSpectraAA-1)
      sf=")";
    };
  c->Print(Form("Output/SpectraComp/%s%s.pdf%s",syspf.Data(),ConfigSF.Data(),sf));
  return minuit;
};
Double_t CalculateChiSquared(Double_t beta1, Double_t Tkin, Double_t norm1, Double_t n) {
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    // set BGBW parameters
    fBGBW[iBW]->SetParameter(0, iBW*1.0);
    fBGBW[iBW]->SetParameter(1, beta1);
    fBGBW[iBW]->SetParameter(2, Tkin);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(4, norm1);

    // loop over all the points
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(rl[iBW] > pt || rh[iBW]<pt) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  return chi;
};
void ResetContours() {
  if(lContours)
    delete lContours;
  lContours = new TList();
  lContours->SetName(Form("ContourList%s",ConfigSF.Data()));
  lContours->SetOwner(kTRUE);
};
void RescaleContourToMeanBeta(TGraph *ingr, Double_t n) {
  Double_t x,y;
  for(Int_t i=0;i<ingr->GetN();i++) {
    ingr->GetPoint(i,x,y);
    x = x/(0.5*(2+n));
    ingr->SetPoint(i,x,y);
  }
}
void PlotFreezeOut(Bool_t DrawPerformance=kFALSE) {
  TGraphErrors *gr = new TGraphErrors();
  FILE *outputpars = fopen(Form("Output/FitParameters/%s.txt",syspf.Data()),"a+");
  TString fixedpars("");
  fixedpars.Append("Single kernel ");
  fprintf(outputpars,"\n\n#%s, fit pions[%1.1f-%1.1f], kaons [%1.1f-%1.1f], protons [%1.1f-%1.1f]. %s\n",
	  syspf.Data(),rl[0],rh[0],rl[1],rh[1],rl[2],rh[2],fixedpars.Data());
  fprintf(outputpars,"#Cmin\tCmax\tN1\t\tN1er\t\tBeta1\t\tBeta1err\tT\t\tTerr\t\tn\t\tnerr");//\tchisq\n");
  fprintf(outputpars,"\t\tChiSq\n");
  gr->SetPoint(0,0,0);
  for(Int_t i=0;i<nSpectraAA;i++) {
    centr=i;
    Init(i);
    TMinuit *mn = PerformFit(DrawPerformance);
    Double_t b1,tk,b1e,tke,n,ne,n1,n1e;
    mn->GetParameter(0,n1,n1e);
    mn->GetParameter(1,b1,b1e);
    mn->GetParameter(2,tk,tke);
    mn->GetParameter(3,n,ne);
    Double_t chisq = CalculateChiSquared(b1,tk,n1,n);
    Int_t np = gr->GetN();
    gr->SetPoint(np,b1/(0.5*(2+n)),tk);
    gr->SetPointError(np,b1e/(0.5*(2+n)),tke);
    fprintf(outputpars,"%i\t%i\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e\t%4.4e",centLow,centHigh,
	    n1,n1e,b1,b1e,tk,tke,n,ne);
    fprintf(outputpars,"\t%4.4e\n",chisq);
  };
  Int_t np=gr->GetN();
  gr->SetPoint(np,1,0.2);
  fclose(outputpars);
  gr->SetTitle(";#LT#beta_{T}#GT;T_{kin}");
  TCanvas *c = new TCanvas("tkin","tkin",600,600);
  gr->Draw("AP");
  gr->SetName(Form("%s%s",syspf.Data(),ConfigSF.Data()));
  if(CalculateContours) {
    TGraph *betatp = new TGraph();
    for(Int_t i=0;i<gr->GetN();i++) betatp->SetPoint(i,gr->GetX()[i],gr->GetY()[i]);
    betatp->SetName(syspf.Data());
    lContours->Add(betatp);
  };
  TFile *tf = new TFile(Form("Output/BetaT/%s.root",syspf.Data()),"UPDATE");
  gr->Write(0,TObject::kOverwrite);
  tf->Close();
};
void PlotAll(TString configname) {
  ReadConfig(configname);
  ResetContours();
  selsys=kpp7;
  PlotFreezeOut(kTRUE);
  selsys=kPbPb276;
  PlotFreezeOut(kTRUE);
  selsys=kpPb502;
  PlotFreezeOut(kTRUE);
  if(CalculateContours) {
    TFile *tf = new TFile("Output/BetaT/Contours.root","UPDATE");
    lContours->Write(0,TObject::kOverwrite+TObject::kSingleKey);
    tf->Close();
  };
}
void PlotAll(){
  PlotAll("Nominal");
  PlotAll("Original");
  PlotAll("LowPt");
  PlotAll("HighPt");
}
