#include "TLegend.h"
TLegend *Legend(Double_t x1=.5, Double_t y1=.5, Double_t x2=.8, Double_t y2=.8) {
  TLegend tlg(x1,y1,x2,y2);
  tlg.SetBorderSize(0);
  tlg.SetFillStyle(0);
  tlg.SetTextFont(42);
  return (TLegend*)tlg.Clone(); 
};
