#include "TF1.h"
#include "TMath.h"
#include "TH3D.h"
#include "TFile.h"
#include "TGraphErrors.h"
#include "TMinuit.h"
#include "TCanvas.h"
#include "Scripts/BuildCanvas.C"
#include "Scripts/ProcessAxii.C"
#include "Scripts/Legend.C"

const Int_t nBW=3;//3; //number of fit species
const Int_t nBWFit=3;
Bool_t onpp=kFALSE;
Bool_t UseTwoKernels=kFALSE;
Bool_t SameNormForTwoKernels=kTRUE;//kFALSE;
Bool_t WithPartialEQ=kFALSE;
Int_t centr = 1; //0-5, 5-10, 10-20, 20-40, 40-60, 60-80 
Int_t nSpectrapp=10;
Int_t nSpectraPbPb=6;
TString KernelFile("Kernels20190308/Keq12_total.root");
const char *PbPbBins[] = {"0-5%","5-10%","10-20%","20-40%","40-60%","60-80%"};
const char *ppBins[] = {"0-1%","1-5%","5-10%","10-15%","15-20%","20-30%","30-40%","40-50%","50-70%","70-100%"};

static TF1 *fBGBlastWave_Integrand = NULL;
TH3D **kernels=NULL;
TH3D **kernels2=NULL;
const Double_t MPion = 0.13957018;
const Double_t MKaon = 0.497648;
const Double_t MProton = 0.938272;
const Double_t MXi = 1.3213;
Double_t masses[] = {MPion, MKaon, MProton,1.3,1.5};
TF1 **fBGBW;
TGraphErrors **gBW, *xi, *om;
TGraphErrors **gBWRat;
Bool_t UseInterpolated=1;//kFALSE;//kTRUE;
Bool_t SingleNorm=1;//0;//kFALSE;
Double_t GetSSFromBeta(Double_t betamax, Double_t wantedss=0.000001) {
  Double_t origN = betamax/wantedss;
  return 1./origN;
};
Double_t rl[] = {0.5,0.5,0.5,0.5,0.5};//{0.5,0.5,0.5,0.7,1.3};//,0.5};//0.2,0.3};
Double_t rh[] = {3.0,3.0,3,3.0,3.0};//1.5,3.0};
TGraph *chib, *chin, *chit;
Double_t
BGBlastWave_Integrand(const Double_t *x, const Double_t *p)
{
  
  /* 
     x[0] -> r (radius)
     p[0] -> mT (transverse mass)
     p[1] -> pT (transverse momentum)
     p[2] -> beta_max (surface velocity)
     p[3] -> T (freezout temperature)
     p[4] -> n (velocity profile)
  */
  
  Double_t r = x[0];
  Double_t mt = p[0];
  Double_t pt = p[1];
  Double_t beta_max = p[2];
  Int_t massind = TMath::Nint(p[5]);
  //  Double_t temp_1 = 1. / p[3];
  Double_t n = p[4];
  Double_t beta = beta_max * TMath::Power(r, n);
  Double_t Tkin = p[3];
  // if(beta<=0.001) printf("Par. set outside range: pT = %f, beta = %f, Tkin = %f\n",pt,beta,p[3]); 
  //if(beta<0.005) beta=0.005;

  Int_t ptind = kernels[massind]->GetXaxis()->FindBin(pt);
  Int_t betai = kernels[massind]->GetYaxis()->FindBin(beta);
  Int_t tempind = kernels[massind]->GetZaxis()->FindBin(Tkin);

  //printf("Attempting to evaluate kernel at (%f, %f, %f)\n",pt,beta,p[3]*1000);
  if(!kernels) printf("Could not fetch kernels!\n");
  Double_t ker;
  if(UseInterpolated)
    ker = kernels[massind]->Interpolate(pt,beta,p[3]);
  else
    ker = kernels[massind]->GetBinContent(ptind,betai,tempind);
  return r * ker;
}

Double_t
BGBlastWave_Func_OneOverPt(const Double_t *x, const Double_t *p)
{  
  Double_t pt = x[0];
  Double_t massInd = p[0];
  Double_t mass = masses[TMath::Nint(massInd)];
  Double_t mt = TMath::Sqrt(pt * pt + mass * mass);
  Double_t beta_max = p[1];
  Double_t temp = p[2];
  Double_t n = p[3];
  Double_t norm = p[4];
  Double_t norm2 = p[SameNormForTwoKernels?4:5];
  if (!fBGBlastWave_Integrand)
    fBGBlastWave_Integrand = new TF1("fBGBlastWave_Integrand", BGBlastWave_Integrand, 0., 1., 6);
  Double_t prs[] = {mt,pt,beta_max,temp,n,massInd};
  fBGBlastWave_Integrand->SetParameters(mt, pt, beta_max, temp, n, massInd);
  Double_t integral = fBGBlastWave_Integrand->Integral(0., 1., prs, 1e-3);//GetSSFromBeta(beta_max));
  Double_t kern2 = kernels2[TMath::Nint(massInd)]->Interpolate(pt,beta_max,temp);
  Double_t k2 = norm2 * kern2; //define norm2 & kern2
  return norm* integral;// + k2;
}
void
BGBlastWave_FCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{
  
  // beta -> beta_max 
  Double_t beta_max = par[nBW+0];
  Double_t T = par[nBW+1];
  Double_t n = par[nBW+2];
  Double_t norm2 = par[nBW+3];
  //Double_t beta_max = 0.5 * (2. + n) * beta;
  
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  // loop over all the data
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    // set BGBW parameters 
    fBGBW[iBW]->SetParameter(0,iBW*1.0);
    fBGBW[iBW]->SetParameter(4, par[SingleNorm?0:iBW]);
    fBGBW[iBW]->SetParameter(1, beta_max);
    fBGBW[iBW]->SetParameter(2, T);
    fBGBW[iBW]->SetParameter(3, n);
    if(!SameNormForTwoKernels)
      fBGBW[iBW]->SetParameter(5, norm2);
    if(iBW>=nBWFit) continue; 
    // loop over all the points 
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  f = chi;
};
TGraphErrors *HtoGr(TH1 *inh, Double_t ptlow, Double_t pthigh) {
  TGraphErrors *retgr = new TGraphErrors();
  Int_t pcount = 0;
  for(Int_t i=inh->FindBin(ptlow+1e-6); i<=inh->FindBin(pthigh-1e-6); i++) {
    retgr->SetPoint(pcount,inh->GetBinCenter(i),inh->GetBinContent(i));
    retgr->SetPointError(pcount,inh->GetBinWidth(i)/2,inh->GetBinError(i));
    //printf("Bin %i with center at %f\n",i, inh->GetBinCenter(i));
    pcount++;
  };
  return retgr;
};
TGraphErrors *MakeRatio(TGraphErrors *ingr, TF1 *inf) {
  TGraphErrors *retgr = new TGraphErrors();
  Double_t x,y,xe,ye;
  for(Int_t i=0;i<ingr->GetN(); i++) {
    ingr->GetPoint(i,x,y);
    if(x>5) break;
    xe = ingr->GetErrorX(i);
    ye = ingr->GetErrorY(i);
    retgr->SetPoint(i,x,y/inf->Eval(x));
    retgr->SetPointError(i,xe,ye/inf->Eval(x));
  };
  return retgr;
};

void Init() { 
  

  if(onpp) {
    TFile *tf = new TFile("ppData.root","READ");
    TH1D *hpi = (TH1D*)tf->Get(Form("pi_V0MPct_%i_Sum",centr+1))->Clone("pis");
    TH1D *hka = (TH1D*)tf->Get(Form("K_V0MPct_%i_Sum",centr+1))->Clone("kas");
    TH1D *hpr = (TH1D*)tf->Get(Form("p_V0MPct_%i_Sum",centr+1))->Clone("prs");
    hpi->SetDirectory(0);
    hka->SetDirectory(0);
    hpr->SetDirectory(0);
    gBW = new TGraphErrors*[nBW];
    TH1D *hs[] = {hpi, hka, hpr};
    for(Int_t i=0;i<3;i++) gBW[i] = HtoGr(hs[i],rl[i],rh[i]);
  } else {
    TFile *tf = new TFile("InputSpectra/PbPbGraphs.root","READ");
    const char *pikpnames[] = {"pi","ka","pr"};
    gBW = new TGraphErrors*[nBW];
    for(Int_t i=0;i<3;i++) gBW[i] = (TGraphErrors*)tf->Get(Form("%s_%i",pikpnames[i],centr));
    tf->Close();
  };
  WithPartialEQ = KernelFile.Contains("PCE");
  if(!kernels) {
    kernels = new TH3D*[5];
    kernels2 = new TH3D*[5];
    const char *nams[] = {"pi0139plu","Ka0492plu","pr0938plu","Xi1321min","UM1672min"};//{"pions","kaons","protons","Xi","Om"};
    TFile *tf = new TFile(KernelFile.Data(),"READ");
    for(Int_t i=0;i<5;i++) {
      kernels[i] = (TH3D*)tf->Get(Form("%s_Keq1",nams[i]))->Clone(Form("%s_Keq1",nams[i]));
      kernels[i]->SetDirectory(0);
      kernels2[i] = (TH3D*)tf->Get(Form("%s_Keq2",nams[i]))->Clone(Form("%s_Keq2",nams[i]));
      kernels2[i]->SetDirectory(0);
    };
    tf->Close();
  };
  fBGBW = new TF1*[nBW];
  for(Int_t i=0;i<nBW;i++) fBGBW[i] = new TF1(Form("BGBW_%i",i),BGBlastWave_Func_OneOverPt,0.2,3,SameNormForTwoKernels?5:6);
};
TMinuit* PerformFit(Bool_t DrawFit=kFALSE, Double_t tfix=0) {
  TMinuit *minuit = new TMinuit(nBW+3);
  minuit->SetFCN(BGBlastWave_FCN);
  Double_t arglist[10];
  Int_t ierflg = 0;
  arglist[0] = 1;
  minuit->mnexcm("SET ERR", arglist, 1, ierflg);
  Double_t norms[] = {1770,1940,800,10,10};
  for (Int_t idata = 0; idata < nBW; idata++)
    minuit->mnparm(idata, Form("Norm_K1%d", idata), norms[idata], 10., 1., 4000., ierflg);
  minuit->mnparm(nBW + 0, "beta_max", 0.6, 0.01, 0.1, 0.985, ierflg);
  minuit->mnparm(nBW + 1, "T", 0.140, 0.001, WithPartialEQ?0.105:0.131, WithPartialEQ?0.145:179, ierflg);
  minuit->mnparm(nBW + 2, "n", 1, 0.01, 0.1, 10., ierflg);
  minuit->mnparm(nBW + 3, "Norm_K2",8,10.,1,4000.,ierflg);
  if(tfix>0.130) {
    minuit->mnparm(nBW + 1, "T", tfix, 0.01, 0.131, 0.179, ierflg);
    minuit->FixParameter(nBW+1);
  };
  if(SameNormForTwoKernels) minuit->FixParameter(nBW+3);
  //minuit->FixParameter(nBW+0);
  if(SingleNorm) {
    minuit->FixParameter(1);
    if(nBW>2) minuit->FixParameter(2);
    if(nBW>3) minuit->FixParameter(3);
    if(nBW>4) minuit->FixParameter(4);
  };

  // minuit->FixParameter(nBW + 1);

  arglist[0] = 1;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);

  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n First MIGRAD ierflg: %i\n\n\n",ierflg);
  
  /* set strategy */
  arglist[0] = 2;
  minuit->mnexcm("SET STRATEGY", arglist, 1, ierflg);
  printf("\n\n\n Set Strategy ierflg: %i\n\n\n",ierflg);

  //UseInterpolated=kTRUE;
  
  /* start MIGRAD minimization */
  arglist[0] = 500000;
  arglist[1] = 1.;
  minuit->mnexcm("MIGRAD", arglist, 2, ierflg);
  printf("\n\n\n Second ierflg: %i\n\n\n",ierflg);
  

  /* start IMPROVE minimization */
  //arglist[0] = 500000;
  minuit->mnexcm("IMPROVE", arglist, 1, ierflg);
  printf("\n\n\n IMPROVE ierflg: %i\n\n\n",ierflg);
  
  /* start MINOS */
  arglist[0] = 500000;
  arglist[1] = nBW + 1;
  arglist[2] = nBW + 2;
  arglist[3] = nBW + 3;
  if(!SameNormForTwoKernels) arglist[4] = nBW + 4;
  minuit->mnexcm("MINOS", arglist, SameNormForTwoKernels?4:5, ierflg);
  //printf("\n\n\n IMPROVE ierflg: %i\n\n\n",ierflg);

    /* print results */
  Double_t amin,edm,errdef;
  Int_t nvpar,nparx,icstat;
  minuit->mnstat(amin, edm, errdef, nvpar, nparx, icstat);
  minuit->mnprin(4, amin);
  if(!DrawFit) return minuit;
  gBWRat = new TGraphErrors*[nBW];
  TCanvas *c = BuildSpagethiCanvas(4);
  TPad *tp;
  Int_t cols[] = {kRed+1, kBlue+1, kGreen+2, kMagenta+2, kBlack};
  Double_t ymin,ymax,trash;
  TLegend *leg = Legend(.396411,.58435,.941272,.885085);
  leg->AddEntry((TObject*)0x0,onpp?Form("pp, #sqrt{s} = 13 TeV, V0M %s",ppBins[centr]):
		Form("Pb-Pb, #sqrt{s_{NN}} = 2.76 TeV, %s",PbPbBins[centr]), "");
  const char *snams[] = {"#pi^{#pm}","K^{#pm}","p+#bar{p}"};
  for(Int_t i=0;i<nBW;i++) {
    //    gBW[i]->GetXaxis()->SetRangeUser(0.3,4.9);
    printf("i = %i\n",i);
    tp = (TPad*)c->FindObject("tp_0");
    tp->cd();
    gBW[i]->Draw(i?"SAME P":"AP");
    gBW[i]->GetXaxis()->SetRangeUser(0,5);
    if(!i) {
      gBW[0]->GetPoint(0,trash,ymax);
      ymin = gBW[2]->Eval(4.9);
      gBW[0]->GetYaxis()->SetRangeUser(0.9*ymin,1.1*ymax);
    };
    ProcessAxisPx(gBW[i]->GetYaxis(),25,0.005,30,2.2,510,0.01);
    gBW[i]->GetYaxis()->SetTitle("#frac{1}{#it{N}_{ev}}#frac{1}{2#pi#it{p}_{T}}#frac{d^{2}#it{N}}{d#it{y}d#it{p}_{T}} [GeV^{2}]");
    if(!i) {
      tp->SetLogy();
      //gBW[i]->GetYaxis()->SetRangeUser(1e-3,1e3);
    };
    gBW[i]->SetLineColor(cols[i]);
    leg->AddEntry(gBW[i],snams[i],"L");
    if(i==2) leg->Draw();
    fBGBW[i]->SetLineColor(cols[i]);
    fBGBW[i]->SetRange(0.3,5);
    fBGBW[i]->Draw("SAME L");
    tp = (TPad*)c->FindObject(Form("tp_%i",i+1));
    tp->cd();
    gBWRat[i] = MakeRatio(gBW[i],fBGBW[i]);
    gBWRat[i]->GetYaxis()->SetLabelSize(0.15);
    gBWRat[i]->GetYaxis()->SetNdivisions(505);
    gBWRat[i]->SetLineColor(cols[i]);
    gBWRat[i]->GetYaxis()->SetRangeUser(0.,2.);
    gBWRat[i]->Draw("AP");
    gBWRat[i]->GetXaxis()->SetRangeUser(0,5);
    gBWRat[i]->SetTitle(";#it{p}_{T} [GeV/#it{c}]; Data/Fit");
    ProcessAxisPx(gBWRat[i]->GetYaxis(),25,0.005,30,2.2,505,0.02);
    ProcessAxisPx(gBWRat[i]->GetXaxis(),25,0.005,30,2.5,506,0.02);

  };
  const char *syspf=onpp?"pp":"PbPb";
  const char *sf="";
  if(!centr) sf="(";
  if((onpp && centr==nSpectrapp-1) || (!onpp && centr==nSpectraPbPb-1))
    sf=")";
  c->Print(Form("outputplots/%sSpectra.pdf%s",syspf,sf));
  //  c2->Print(Form("outputplots/%sRatios_%i.png",syspf,centr));
  return minuit;
};
void StoreToFile(const char *fout, const char *pf=0) {
  TFile *tfout = new TFile(fout, "UPDATE");
  if(pf) {
    for(Int_t i=0;i<nBW;i++) {
      fBGBW[i]->SetName(Form("%s%s",fBGBW[i]->GetName(),pf));
      gBW[i]->SetName(Form("%s%s",fBGBW[i]->GetName(),pf));
      gBWRat[i]->SetName(Form("%s%s",fBGBW[i]->GetName(),pf));
    };
  };
  for(Int_t i=0;i<nBW;i++) {
    fBGBW[i]->Write();
    gBW[i]->Write();
    gBWRat[i]->Write();
  };
  tfout->Close();
};
Double_t CalculateChiSquared(Double_t bm, Double_t Tkin, Double_t norm1, Double_t norm2, Double_t n) {
  Double_t pt, pte, val, vale, func, pull, chi = 0;
  for (Int_t iBW = 0; iBW < nBW; iBW++) {
    // set BGBW parameters 
    fBGBW[iBW]->SetParameter(0,iBW*1.0);
    fBGBW[iBW]->SetParameter(4, norm1);
    fBGBW[iBW]->SetParameter(1, bm);
    fBGBW[iBW]->SetParameter(2, Tkin);
    fBGBW[iBW]->SetParameter(3, n);
    fBGBW[iBW]->SetParameter(5, norm2);
    // loop over all the points 
    for (Int_t ipt = 0; ipt < gBW[iBW]->GetN(); ipt++) {
      pt = gBW[iBW]->GetX()[ipt];
      if(rl[iBW] > pt || rh[iBW]<pt) continue;
      pte = gBW[iBW]->GetErrorX(ipt);
      val = gBW[iBW]->GetY()[ipt];
      func = fBGBW[iBW]->Eval(pt);
      //      func = fBGBW[iBW]->Integral(pt - pte, pt + pte);
      pull = (val - func);//  / vale;
      vale = gBW[iBW]->GetErrorY(ipt);//(pull>0)?gBW[iBW]->GetErrorYlow(ipt):gBW[iBW]->GetErrorYhigh(ipt);
      if(vale<=0) printf("Bin %i in graph %i: val. err: %f\n",ipt,iBW,vale);
      pull = pull/vale;
      chi += pull * pull;
    }
  }
  return chi;
};
void MakeChiGraphs() {
  chib=new TGraph();
  chin=new TGraph();
  chit=new TGraph();
  Double_t pars[2];
  Double_t bm,n;
  Double_t trash;
  for(Double_t t=0.131; t<0.170; t+=0.001) {
    printf("t = %f\n\n\n",t);
    TMinuit *mn = PerformFit(t);
    mn->GetParameter(2,bm,trash);
    mn->GetParameter(4,n,trash);
    mn->GetParameter(0,pars[0],trash);
    mn->GetParameter(1,pars[1],trash);
    printf("Parameters: %f, %f, %f, %f, %f\n",bm,t,n,pars[0],pars[0]);
    Double_t chisq=1;//CalculateChiSquared(bm,t,n,pars);
    printf("chisq = %f\n\n\n",chisq);
    chib->SetPoint(chib->GetN(),t,bm);
    chin->SetPoint(chin->GetN(),t,n);
    chit->SetPoint(chit->GetN(),t,chisq);
    delete mn;
  };
};

void PlotFreezeOut(Bool_t DrawPerformance=kFALSE) {
  TGraphErrors *gr = new TGraphErrors();
  FILE *outputpars = fopen(Form("%s_FitParameter.txt",(onpp?"pp":"PbPb")),"a+");
  TString fixedpars("");
  if(SameNormForTwoKernels) fixedpars.Append("Norm2 ");
  fprintf(outputpars,"%s, fit pions[%1.1f-%1.1f], kaons [%1.1f-%1.1f], protons [%1.1f-%1.1f]; fixed parameters: %s\n",
	  onpp?"pp":"PbPb",rl[0],rh[0],rl[1],rh[1],rl[2],rh[2],fixedpars.Data());
  fprintf(outputpars,"Cent.\tNorm1\t\tNorm1err\tNorm2\tNorm2err\tBetaM\tBetaMerr\tTkin\tTkinerr\tn\tnerr\tchisq\n");
  for(Int_t i=0;i<(onpp?nSpectrapp:nSpectraPbPb);i++) {
    centr=i;
    Init();
    TMinuit *mn = PerformFit(DrawPerformance);
    Double_t x,y,xe,ye,n,ne,A,Ae, A2, A2e;
    mn->GetParameter(3,x,xe);
    mn->GetParameter(4,y,ye);
    mn->GetParameter(5,n,ne);
    mn->GetParameter(0,A,Ae);
    mn->GetParameter(6,A2,A2e);
    Double_t chisq = CalculateChiSquared(x,y,A,A2,n);
    Int_t np = gr->GetN();
    gr->SetPoint(np,x/(0.5*(2+n)),y);
    gr->SetPointError(np,xe/(0.5*(2+n)),ye);
    fprintf(outputpars,"%s\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",PbPbBins[centr],A,Ae,A2,A2e,x,xe,y,ye,n,ne,chisq); 
    /* fprintf(outputpars,"%s, %s\n",onpp?"pp":"Pb-Pb",onpp?ppBins[centr]:PbPbBins[centr]);
    fprintf(outputpars,"Norm: %f +- %f\n",A,Ae);
    fprintf(outputpars,"Beta_max: %f +- %f\n",x,xe);
    fprintf(outputpars,"Tkin: %f +- %f\n",y,ye);
    fprintf(outputpars,"n: %f +- %f\n",n,ne);
    fprintf(outputpars,"Norm2: %f +- %f\n",A2,A2e);*/
  };
  fclose(outputpars);
  gr->SetTitle(";#LT#beta_{T}#GT;T_{kin}");
  TCanvas *c = new TCanvas("tkin","tkin",600,600);
  gr->Draw("AP");
  gr->SetName("PbPb");
  TFile *tf = new TFile(Form("%sTKin.root",onpp?"pp_v2":"PbPb_v2"),"RECREATE");
  gr->Write();
  tf->Close();
};
