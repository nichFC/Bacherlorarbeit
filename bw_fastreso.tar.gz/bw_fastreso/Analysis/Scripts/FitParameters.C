#ifndef FITPARS
#define FITPARS
#include "TNamed.h"
#include "TGraph.h"
#include "TMinuit.h"
#include "TString.h"
class FitPars: public TNamed {
  public:
    FitPars();
    ~FitPars();
    FitPars(TMinuit *inmin, Double_t dNde=0, TGraph *contour=0);
    Double_t GetPar(TString par);
    const char *GetFlagTitle(TString par);
    Double_t fN;
    Double_t fNErr;
    Double_t fBeta;
    Double_t fBetaErr;
    Double_t fTkin;
    Double_t fTkinErr;
    Double_t fNexp;
    Double_t fNexpErr;
    Double_t fdNde;
    TGraph *fContour;
  ClassDef(FitPars, 1);
};
FitPars::FitPars():
  fN(0),
  fNErr(0),
  fBeta(0),
  fBetaErr(0),
  fTkin(0),
  fTkinErr(0),
  fNexp(0),
  fNexpErr(0),
  fdNde(0),
  fContour(0) {
};
FitPars::~FitPars() {
  if(fContour) delete fContour;
};
FitPars::FitPars(TMinuit *mn, Double_t dNde, TGraph *contour) {
  mn->GetParameter(0,fN,fNErr);
  mn->GetParameter(1,fBeta,fBetaErr);
  mn->GetParameter(2,fTkin,fTkinErr);
  mn->GetParameter(3,fNexp,fNexpErr);
  fBeta = 2*fBeta/(2+fNexp);
  fBetaErr = 2*fBetaErr/(2+fNexp);
  if(dNde) fdNde = dNde;
  if(contour) fContour=(TGraph*)contour->Clone(contour->GetName());
};
Double_t FitPars::GetPar(TString par) {
  if(par.Contains("dNde",TString::kIgnoreCase)) return par.Contains("err",TString::kIgnoreCase)?0:fdNde;
  if(par.Contains("beta",TString::kIgnoreCase)) return par.Contains("err",TString::kIgnoreCase)?fBetaErr:fBeta;
  if(par.Contains("tkin",TString::kIgnoreCase)) return par.Contains("err",TString::kIgnoreCase)?fTkinErr:fTkin;
  if(par.Contains("nexp",TString::kIgnoreCase)) return par.Contains("err",TString::kIgnoreCase)?fNexpErr:fNexp;
  if(par.Contains("norm",TString::kIgnoreCase)) return par.Contains("err",TString::kIgnoreCase)?fNErr:fN;
  return 0;
}
const char *FitPars::GetFlagTitle(TString par) {
  if(par.Contains("dNde",TString::kIgnoreCase)) return "#LTd#it{N}_{ch}/d#it{#eta}#GT";
  if(par.Contains("beta",TString::kIgnoreCase)) return "#LT#it{#beta}_{T}#GT";
  if(par.Contains("tkin",TString::kIgnoreCase)) return "#it{T}_{kin} (GeV)";
  if(par.Contains("nexp",TString::kIgnoreCase)) return "#it{n}_{exp}";
  if(par.Contains("norm",TString::kIgnoreCase)) return "Normalization";
  return Form("Undefined_%s",par.Data());
}
#endif
