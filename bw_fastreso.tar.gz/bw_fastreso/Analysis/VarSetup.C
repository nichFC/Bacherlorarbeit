#ifndef SETUPVARS
#define SETUPVARS
#include "TString.h"
#include "TFile.h"
#include "TList.h"
#include "TGraph.h"
#include "TLegend.h"
#include "TH1D.h"


enum SystDesc {kpp7, kpPb502, kPbPb276, kClosure, kpp13, kPbPb276MS, kpp7MS, kPbPb502, kPbPb276HF, kPbPb502HF};
SystDesc selsys = kPbPb276;
TString ConfigSF("");
TString LegDesc="";
TString LegDescNoMulti="";
TString infile="";
TString ingrdesc="";
TString syspf="";
Int_t nSpectraAA=1;
Int_t centr = 0; //0-5, 5-10, 10-20, 20-40, 40-60, 60-80
Int_t nBW=3;//number of species
TString fittypePF("");

//Configuration for different fit modes
TString KernelFile("Kernels/K_full_total.root");
enum FitDesc {kNormal, kOldPdg, kPCE140, kPCE145, kPCE150, kPCE150old, kPCE155, kPCE160, kPCE165, kViscous, kViscousPCE155, kViscousPCE145, kCoarse, kThermal, kCharm, kCharmThermal};
FitDesc fittype = kNormal;
Bool_t IncludeViscous=kFALSE;
Double_t TkinMin=0.130;
Double_t TkinMax=0.175;


const char *PbPbBins[] = {"0-5%","5-10%","10-20%","20-30%","30-40%","40-50%","50-60%","60-70%","70-80%","80-90%"};
const Int_t PbPbBinsInt[] = {0,5,10,20,30,40,50,60,70,80,90};
const char *pPbBins[] = {"0-5%","5-10%","10-20%","20-40%","40-60%","60-80%","80-100%"};
const Int_t pPbBinsInt[] = {0,5,10,20,40,60,80,100};
const char *ppBins[] = {"0-1%","1-5%","5-10%","10-15%","15-20%","20-30%","30-40%","40-50%","50-70%","70-100%"};
const Int_t ppBinsInt[] = {0,1,5,10,15,20,30,40,50,70,100};
//For HF (5 TeV)
//const char *PbPbHFBins[] = {"0-5%","5-10%","10-20%","20-30%","30-40%","40-50%","50-60%","60-70%","70-80%","80-90%"};
//const Int_t PbPbHFBinsInt[] = {0,5,10,20,30,40,50,60,70,80,90};
const char *PbPbHFBins[] = {"0-10%","30-50%","60-80%"};
const Int_t PbPbHFBinsInt[] = {0,10,30,80};

//For performance with multistrange
const char *PbPbBinsMS[] = {"0-10%","10-20%","20-40%","40-60%","60-80%"};
const Int_t PbPbBinsIntMS[] = {0,10,20,40,60,80};
const char *PbPbHFBinsMS[] = {"0-10%","10-20%","20-40%","40-60%","60-80%"};
const Int_t PbPbHFBinsIntMS[] = {0,10,20,40,60,80};
const char *ppBinsMS[] = {"0-5%","5-15%","15-30%","30-50%","50-100%"};
const Int_t ppBinsIntMS[] = {0,10,20,40,60,80};




Double_t *dNde;
Double_t dNdepp7[]  = {21.294, 16.513, 13.457, 11.507, 10.08, 8.447, 6.724, 5.398, 3.897, 2.261};
Double_t dNdepPb[]  = {45.2108, 36.2, 30.5, 23.2, 16.1, 9.8, 4.4};
Double_t dNdePbPb[] = {1601., 1294., 966., 649., 426., 261., 149., 76., 35., 13.4};
Double_t dNdepp13[] = {26.22, 20.05, 16.18, 13.78, 12.02, 10.02, 7.93, 6.29, 4.45, 2.42};
Double_t dNdeClosure[] = {1};
Int_t centLow=0;
Int_t centHigh=0;
Double_t rl[] = {0.5,0.5,0.5,0.5};//{0.5,0.5,0.5,0.5,0.5};//{0.5,0.5,0.5,0.7,1.3};//,0.5};//0.2,0.3};
Double_t rh[] = {3.,3.,3.,3.};//{3.0,3.0,3,3.0,3.0};//1.5,3.0};
Double_t GetMaxN(Int_t cent) {
  Double_t MaxN = 10;
  if(ConfigSF.Contains("HighPt")) {
    if(selsys==kpp7) {
      MaxN=2+cent;
    }
    if(selsys==kpPb502) {
      MaxN=2+cent;
    }
    if(selsys==kPbPb276) {
      MaxN=5;
    }
    if(selsys==kPbPb276MS) {
      MaxN=5;
    }
  };
  if(ConfigSF.Contains("NewCuts")) {
    if(selsys==kpp7) {
      MaxN=2+cent;
    }
    if(selsys==kpPb502) {
      MaxN=2+cent;
    }
    if(selsys==kPbPb276) {
      MaxN=5;
    }
    if(selsys==kPbPb276MS) {
      MaxN=5;
    }
  };
  if(ConfigSF.Contains("LowPt")) {
    if(selsys==kpp7) {
      MaxN=cent+2;
    }
    if(selsys==kpPb502) {
      MaxN=2+cent;
    }
    if(selsys==kPbPb276) {
      MaxN=5;
    }
    if(selsys==kPbPb276MS) {
      MaxN=5;
    }
  }
  if(ConfigSF.Contains("Original")) {
    if(selsys==kpp7) {
      MaxN=cent+2;
    }
    if(selsys==kpPb502) {
      MaxN=2+cent;
    }
    if(selsys==kPbPb276) {
      MaxN=5;
    }
    if(selsys==kPbPb276MS) {
      MaxN=5;
    }
  }
  if(ConfigSF.IsNull()) {
    if(selsys==kpp7) {
      MaxN=cent+2;
    }
    if(selsys==kpPb502) {
      MaxN=2+cent;
    }
    if(selsys==kPbPb276) {
      MaxN=10;
    }
    if(selsys==kPbPb276MS) {
      MaxN=5;
    }
    if(selsys==kpp13) {
      MaxN=cent+2;
    }
  }
  return MaxN;
}
void SetupFitType(FitDesc desc) {
  if(fittype!=desc) fittype=desc;
  KernelFile = TString("Kernels/");
  switch(fittype) {
    case kNormal:
      printf("Setting up normal fit type\n");
      IncludeViscous=kFALSE;
      TkinMin=0.130;
      TkinMax=0.175;
      KernelFile.Append("K_total_full_pdg16.root");
      fittypePF="Normal";
      break;
    case kOldPdg:
      printf("Setting up normal fit type\n");
      IncludeViscous=kFALSE;
      TkinMin=0.130;
      TkinMax=0.175;
      KernelFile.Append("K_full_total.root");
      fittypePF="Normal_OldPdg";
      break;
    case kPCE140:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.1400Tmax0.2000Tmin0.1000full_total_partial.root");
      fittypePF="PCE140";
      break;
    case kPCE145:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.1450Tmax0.2000Tmin0.1000full_total_partial.root");
      fittypePF="PCE145";
      break;
    case kPCE150:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.1500Tmax0.2000Tmin0.1000full_total_partial.root");
      fittypePF="PCE150";
      break;
    case kPCE150old:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.150.root");
      fittypePF="PCE150";
      break;
    case kPCE155:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.1550Tmax0.2000Tmin0.1000full_total_partial.root");
      fittypePF="PCE155";
      break;
    case kPCE160:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.1600Tmax0.2000Tmin0.1000full_total_partial.root");
      fittypePF="PCE160";
      break;
    case kPCE165:
      IncludeViscous=kFALSE;
      TkinMin=0.101;
      TkinMax=0.199;
      KernelFile.Append("K_Tchem0.1650Tmax0.2000Tmin0.1000full_total_partial.root");
      fittypePF="PCE165";
      break;
  /*  case kPCE160:
      IncludeViscous=kFALSE;
      TkinMin=0.110;
      TkinMax=0.160;
      KernelFile.Append("K_Tmax0.1600Tmin0.1100full_total_partial.root");
      fittypePF="PCE160";
      break;
    case kPCE165:
      IncludeViscous=kFALSE;
      TkinMin=0.115;
      TkinMax=0.165;
      KernelFile.Append("K_Tmax0.1650Tmin0.1150full_total_partial.root");
      fittypePF="PCE165";
      break;
    case kPCE145:
      IncludeViscous=kFALSE;
      TkinMin=0.096;
      TkinMax=0.145;
      KernelFile.Append("K_Tmax0.1450Tmin0.0950full_total_partial.root");
      fittypePF="PCE145";
      break;*/
    case kViscous:
      IncludeViscous=kTRUE;
      TkinMin=0.130;
      TkinMax=0.175;
      KernelFile.Append("K_full_total.root");
      fittypePF="PCE165";
      break;
    case kViscousPCE155:
      IncludeViscous=kTRUE;
      TkinMin=0.105;
      TkinMax=0.154;
      KernelFile.Append("K_Tmax0.1550Tmin0.1050full_total_partial.root");
      fittypePF = "ViscousPCE155";
      break;
    case kViscousPCE145:
      IncludeViscous=kTRUE;
      TkinMin=0.105;
      TkinMax=0.144;
      KernelFile.Append("K_Tmax0.1450Tmin0.1050full_total_partial.root");
      fittypePF = "ViscousPCE145";
      break;
    case kCoarse:
      IncludeViscous=kFALSE;
      TkinMin=0.105;
      TkinMax=0.195;
      KernelFile.Append("K_full_total_T100_200.root");
      fittypePF = "Coarse";
      break;
    case kThermal:
      IncludeViscous=kFALSE;
      TkinMin=0.105;
      TkinMax=0.195;
      KernelFile.Append("K_full_thermal.root");
      fittypePF = "Thermal";
      break;
    case kCharm:
      IncludeViscous=kFALSE;
      TkinMin=0.140;
      TkinMax=0.160;
      KernelFile.Append("K_charm_total.root");
      fittypePF="Charm";
      break;
    case kCharmThermal:
      IncludeViscous=kFALSE;
      TkinMin=0.140;
      TkinMax=0.160;
      KernelFile.Append("K_charm_thermal.root");
      fittypePF="Charm_Thermal";
      break;
    default:
      IncludeViscous=kFALSE;
      TkinMin=0.130;
      TkinMax=0.175;
      KernelFile.Append("K_full_total.root");
      fittypePF = "Default";
      break;
  }
}
void SetupVariables(SystDesc insys) {
  if(selsys!=insys) selsys=insys;
  switch(insys) {
    case kpp7:
      LegDesc = Form("pp, #sqrt{#it{s}} = 7 TeV, V0M %s",ppBins[centr]);
      LegDescNoMulti = "pp, #sqrt{#it{s}} = 7 TeV";
      syspf="pp7TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=10;
      centLow=ppBinsInt[centr];
      centHigh=ppBinsInt[centr+1];
      dNde=dNdepp7;
      break;
    case kpp13:
      LegDesc = Form("pp, #sqrt{#it{s}} = 13 TeV, V0M %s",ppBins[centr]);
      LegDescNoMulti = "pp, #sqrt{#it{s}} = 13 TeV";
      syspf="pp13TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";//"%s_V0MPct_%i_Sum";
      nSpectraAA=10;
      dNde=dNdepp13;
      break;
    case kpPb502:
      LegDesc = Form("p-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV, V0M %s",pPbBins[centr]);
      LegDescNoMulti = "p-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV";
      syspf="pPb502TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=7;
      centLow=pPbBinsInt[centr];
      centHigh=pPbBinsInt[centr+1];
      dNde=dNdepPb;
      break;
    case kPbPb276:
      LegDesc = Form("Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV, V0M %s",PbPbBins[centr]);
      LegDescNoMulti = "Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV";
      syspf="PbPb276TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=10;
      centLow=PbPbBinsInt[centr];
      centHigh=PbPbBinsInt[centr+1];
      dNde=dNdePbPb;
      break;
    case kPbPb276MS:
      LegDesc = Form("Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV, V0M %s",PbPbBinsMS[centr]);
      LegDescNoMulti = "Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV";
      syspf="PbPb276TeV_MS";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=5;
      centLow=PbPbBinsIntMS[centr];
      centHigh=PbPbBinsIntMS[centr+1];
      dNde=dNdePbPb;
      break;
    case kpp7MS:
      LegDesc = Form("pp, #sqrt{#it{s}} = 7 TeV, V0M %s",ppBins[centr]);
      LegDescNoMulti = "pp, #sqrt{#it{s}} = 7 TeV";
      syspf="pp7TeV_MS";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=5;
      centLow=ppBinsIntMS[centr];
      centHigh=ppBinsIntMS[centr+1];
      dNde=dNdepp7;
      break;
    case kPbPb502:
      LegDesc = Form("Pb-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV, V0M %s",PbPbBins[centr]);
      LegDescNoMulti = "Pb-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV";
      syspf="PbPb5TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=10;
      centLow=PbPbBinsInt[centr];
      centHigh=PbPbBinsInt[centr+1];
      dNde=dNdePbPb;
      break;
    case kPbPb276HF:
      LegDesc = Form("Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV, V0M %s",PbPbBins[centr]);
      LegDescNoMulti = "Pb-Pb, #sqrt{#it{s}_{NN}} = 2.76 TeV";
      syspf="PbPb276TeV";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=10;
      centLow=PbPbBinsInt[centr];
      centHigh=PbPbBinsInt[centr+1];
      dNde=dNdePbPb;
      break;
    case kPbPb502HF:
      LegDesc = Form("Pb-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV, V0M %s",PbPbHFBins[centr]);
      LegDescNoMulti = "Pb-Pb, #sqrt{#it{s}_{NN}} = 5.02 TeV";
      syspf="PbPb5TeV_HF";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=3;
      centLow=PbPbHFBinsInt[centr];
      centHigh=PbPbHFBinsInt[centr+1];
      dNde=dNdePbPb;
      break;

    case kClosure:
      LegDesc = Form("Closure test");
      syspf="Closure";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=1;
      dNde=dNdeClosure;
      break;
    default:
      LegDesc = Form("Closure test");
      syspf="Closure";
      infile = Form("InSpectra/%s.root",syspf.Data());
      ingrdesc = "%s_%i";
      nSpectraAA=1;
      dNde = dNdeClosure;
      break;
  }
}
void ReadConfig(TString ConfigFile) {
  FILE *infi = fopen(Form("Configs/%s",ConfigFile.Data()),"r");
  ConfigSF=ConfigFile.EqualTo("Nominal")?"":ConfigFile.Data();
  for(Int_t i=0;i<3;i++) fscanf(infi,"%lf %lf",&rl[i],&rh[i]);
  fclose(infi);
}
Int_t GetNBW(Int_t cent) {
  if(selsys==kPbPb276) {
      return 3;
  }
  if(selsys==kPbPb276HF) {
      return 9;
  }
  if(selsys==kPbPb502HF) {
      return 9;
  }
  if(selsys==kpp7) {
    return 3;
  }
  if(selsys==kPbPb276MS) {
      return 6;
  }
  if(selsys==kpPb502) {
    return 6;
  }
  if(selsys==kpp7MS) {
    return 6;
  }
  return 3;
}
TFile *OpenFile(const char *infile) {
  TFile *retfile = new TFile(infile,"READ");
  if(!retfile) {
    printf("Error: Could not find file %s\n",infile);
    return 0;
  };
  if(retfile->IsZombie()) {
    printf("Error: File %s is a zombie\n",infile);
    return 0;
  };
  return retfile;
};
TGraph *GetGraph(TFile *infile, const char *grname) {
  TGraph *retgr = (TGraph*)infile->Get(grname);
  if(!retgr) { printf("Could not fetch %s from %s\n",grname,infile->GetName()); return 0; };
  return retgr;
}
TGraph *GetGraph(TList *tl, const char *grname) {
  if(!tl) { printf("No list provided!\n"); return 0;}
  TGraph *retgr = (TGraph*)tl->FindObject(grname);
  if(!retgr) { printf("Could not fetch %s from list %s\n",grname, tl->GetName()); return 0; };
  return retgr;
}
TList *GetList(TFile *infile, const char *lname) {
  TList *retl = (TList*)infile->Get(lname);
  if(!retl) {
    printf("Could not fetch list %s from %s\n",lname,infile->GetName());
    return 0;
  }
  return retl;
};
TH1D *GetHist(TFile *infile, const char *histname) {
  if(!infile) { printf("File not opened!\n"); return 0; };
  TH1D *rethist = (TH1D*)infile->Get(histname);
  if(!rethist) { printf("Could not find %s in %s\n",histname,infile->GetName()); return 0; };
  rethist = (TH1D*)rethist->Clone(histname);
  rethist->SetDirectory(0);
  return rethist;
}
TLegend *Legend(Double_t x1=.5, Double_t y1=.5, Double_t x2=.8, Double_t y2=.8) {
  TLegend *tleg = new TLegend(x1,y1,x2,y2);
  tleg->SetFillStyle(0);
  tleg->SetBorderSize(0);
  tleg->SetTextFont(43);
  tleg->SetTextSize(25);
  return tleg;
};
#endif
