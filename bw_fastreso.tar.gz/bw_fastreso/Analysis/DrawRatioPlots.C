#include "TFile.h"
#include "TGraphErrors.h"
#include "TCanvas.h"
#include "Scripts/BuildCanvas.C"
#include "Scripts/ProcessAxii.C"
#include "TLegend.h"
#include "Scripts/Colors.h"
#include "TLine.h"
#include "VarSetup.C"
#include "TPad.h"
#include "TLatex.h"
#include "TLine.h"
#include "TF1.h"
#include "TArrow.h"

Bool_t OnMultiStrange=kFALSE;
Bool_t RatiosInSigma=kFALSE;
void DrawRatioPlotsMS(FitDesc lfittype);
TFile *Init(const char *infile="Output/BetaT/PbPb276TeV.root") {
  TFile *tf = new TFile(infile,"READ");
  return tf;
}
TFile *tf=0;
TGraphErrors* GetGraph(const char *grname) {
  if(!tf) tf = OpenFile("OtherOutput/BWRatios.root");
  if(!tf) printf("Could not open file!\n");
  TGraphErrors *gr = (TGraphErrors*)GetGraph(tf,grname);
  if(RatiosInSigma) {
    Double_t *yvals=gr->GetY();
    Double_t *yerrs=gr->GetEY();
    for(Int_t i=0;i<gr->GetN();i++) {
      yvals[i] = (yvals[i]-1)/yerrs[i];
      yerrs[i] = 0;
    }
  }
  gr->SetPoint(0,-1,0);
  gr->GetXaxis()->SetRangeUser(-0.1,3.55);
  gr->GetYaxis()->SetRangeUser(0.1,1.9);
  if(OnMultiStrange) gr->GetYaxis()->SetRangeUser(0.1,1.9);
  if(RatiosInSigma)  gr->GetYaxis()->SetRangeUser(-4,4);
  ProcessAxisPx(gr->GetYaxis(),20,0.005,20,1,105,0.03);
  ProcessAxisPx(gr->GetXaxis(),20,0.005,20,1,505,0.03);
  gr->SetLineColor(kBlack);
  gr->SetMarkerStyle(20);
  gr->SetMarkerColor(kBlack);
  for(Int_t i=0;i<gr->GetN();i++) gr->GetEX()[i] = 0;
  return gr;
}
TGraphErrors* GetSpectra(const char *grname) {
  if(!tf) tf = OpenFile("OtherOutput/BWRatios.root");
  if(!tf) printf("Could not open file!\n");
  TGraphErrors *gr = (TGraphErrors*)GetGraph(tf,grname);
  gr->SetPoint(0,-1,0);
  gr->GetXaxis()->SetRangeUser(-0.1,3.55);
//  gr->GetYaxis()->SetRangeUser(0.5,1.5);
  ProcessAxisPx(gr->GetYaxis(),25,0.005,30,1.5,105,0.03);
  ProcessAxisPx(gr->GetXaxis(),25,0.005,30,1.5,505,0.03);
  gr->SetLineColor(kBlack);
  gr->SetMarkerStyle(0);
  gr->SetMarkerColor(kBlack);
  gr->GetYaxis()->SetRangeUser(1e-3,3000);
  return gr;
}
TF1 *GetFunc(const char *funname) {
  if(!tf) tf = OpenFile("OtherOutput/BWRatios.root");
  if(!tf) printf("Could not open file!\n");
  TF1 *retfunc = (TF1*)tf->Get(funname);
  return retfunc;
}
TGraphErrors *GetGraph(SystDesc systype, Int_t specie, Int_t cent) {
  SetupVariables(systype);
  //SetupFitType(kNormal);
  TGraphErrors *retgr = GetGraph(Form("Ratio_%s_%i_cent_%i_%s",syspf.Data(),specie,cent,fittypePF.Data()));
  retgr->SetTitle(";;");
  return retgr;
}
void DrawRatioPlots(FitDesc lfittype) {
  SetupFitType(lfittype);
  TCanvas *c = BuildCanvasMatrix(3,3,150,250,0.22,0.31,0.2,0.01);
  SystDesc sds[] = {kPbPb276,kpPb502,kpp7};
  Int_t droff=0;
  if(OnMultiStrange) { sds[0]= kPbPb276MS; sds[2]=kpp7MS; droff=3;};
  for(Int_t cs=0;cs<3;cs++) {
    for(Int_t sp=0;sp<3;sp++) {
      SetupFitType(fittype);
      TPad *tp = (TPad*)c->FindObject(Form("tp_%i_%i",cs,sp));
      tp->cd();
      TGraphErrors *grhm = GetGraph(sds[cs],sp+droff,0);
      grhm->SetMarkerStyle(20);
      grhm->SetMarkerColor(kBlack);
      grhm->Draw("AP");
      ProcessAxisPx(grhm->GetYaxis(),30,0.005,30,1,105,0.03);
      ProcessAxisPx(grhm->GetXaxis(),30,.005,30,1,505,0.03);
      TGraphErrors *grlm = GetGraph(sds[cs],sp+droff,nSpectraAA-1);
      grlm->SetMarkerStyle(24);
      grlm->SetMarkerColor(kBlack);
      grlm->Draw("SAME P");
      TLine *tl = new TLine(-0.1,RatiosInSigma?0:1,3.55,RatiosInSigma?0:1);
      tl->SetLineStyle(2);
      tl->Draw("SAME");
    }
  }
  TLatex *tlat = new TLatex();
  tlat->SetTextFont(43);
  TPad *tp = (TPad*)c->FindObject("tp_0_2");
  tp->cd();
  TArrow *ar = new TArrow(0.5,0.2,3,0.2,0.02,"|-----|");
  ar->SetLineWidth(3);
  ar->Draw();
  tlat->SetTextSize(25);
  tlat->SetTextAlign(22);
  tlat->DrawLatex(1.75,0.37,"Fit range");
  tlat->SetTextAlign(11);

  tp = (TPad*)c->FindObject("mask");
  tp->cd();
  tlat->SetTextSize(35);
  tlat->SetTextAngle(90);
  tlat->DrawLatex(0.031,.44,RatiosInSigma?"(Data-fit)/#sigma":"Data/fit");
  tlat->SetTextAngle(0);
  tlat->SetTextSize(27);
  SetupVariables(kPbPb276);
  tlat->DrawLatex(0.0507963,0.954,LegDescNoMulti.Data());
  SetupVariables(kpPb502);
  tlat->DrawLatex(.4017,0.954,LegDescNoMulti.Data());
  SetupVariables(kpp7);
  tlat->DrawLatex(0.7501,0.954,LegDescNoMulti.Data());
  tlat->SetTextSize(30);
  const char *splbs[] = {"#pi","K","p","#Lambda","#Xi","#Omega"};
  tlat->DrawLatex(0.125,0.89,splbs[0+droff]);
  tlat->DrawLatex(0.125,.59,splbs[1+droff]);
  tlat->DrawLatex(0.125,0.33,splbs[2+droff]);

  tlat->DrawLatex(0.425,0.89,splbs[0+droff]);
  tlat->DrawLatex(0.4255,.59,splbs[1+droff]);
  tlat->DrawLatex(0.425,0.33,splbs[2+droff]);

  tlat->DrawLatex(0.725,0.89,splbs[0+droff]);
  tlat->DrawLatex(0.725,.59,splbs[1+droff]);
  tlat->DrawLatex(0.725,0.33,splbs[2+droff]);
  tlat->SetTextSize(35);
  tlat->DrawLatex(.45,0.0253906,"#it{p}_{T} (GeV/#it{c})");
  // tlat->SetTextSize(27);
  // tlat->DrawLatex(.11,.415,"0.5 < #it{p}_{T} < 3 (GeV/#it{c})");
  TGraph *dummyblank = new TGraph();
  dummyblank->SetMarkerStyle(24);
  TGraph *dummyfull = new TGraph();
  dummyfull->SetMarkerStyle(20);
  TLegend *legpbpb = Legend(.08,.54,.38,.84);
  legpbpb->SetNColumns(2);
  legpbpb->AddEntry(dummyfull,PbPbBins[0],"P");
  legpbpb->AddEntry(dummyblank,PbPbBins[9],"P");
  legpbpb->Draw();
  TLegend *legppb = Legend(.40,.54,.71,.84);
  legppb->SetNColumns(2);
  legppb->AddEntry(dummyfull,pPbBins[0],"P");
  legppb->AddEntry(dummyblank,pPbBins[6],"P");
  legppb->Draw();
  TLegend *legpp = Legend(.70,.54,1.0,.84);
  legpp->SetNColumns(2);
  legpp->AddEntry(dummyfull,ppBins[0],"P");
  legpp->AddEntry(dummyblank,ppBins[9],"P");
  legpp->Draw();
  const char *mssubfix="";
  if(OnMultiStrange) mssubfix="_MS";
  c->Print(Form("../Figures/%s%s%s.pdf",RatiosInSigma?"NSigma":"DataToFitRatios",mssubfix,fittypePF.Data()));
};
void DrawAllRatios() {
  OnMultiStrange=kFALSE;
  DrawRatioPlots(kPCE140);
  DrawRatioPlots(kPCE145);
  DrawRatioPlots(kPCE150);
  DrawRatioPlots(kPCE155);
  DrawRatioPlots(kPCE160);
  DrawRatioPlots(kPCE165);
  DrawRatioPlots(kNormal);
  //return;
  OnMultiStrange=kTRUE;
  //DrawRatioPlots(kNormal);
  DrawRatioPlotsMS(kNormal);
  DrawRatioPlotsMS(kPCE155);
  OnMultiStrange=kFALSE;
}
void DrawSingleSpectra() {
  TCanvas *c = BuildSingleCanvas(600,600);
  c->SetLogy();
  SetupVariables(kPbPb276MS);
  Int_t nbw = GetNBW(selsys);
  Int_t cols = CreateColors(nbw);
  SetupFitType(kNormal);
  TLegend *leg = Legend(0.5907,.763,.9295,0.9440);//.21,0.14,.53,.32);//396411,.58435,.941272,.885085);
  leg->AddEntry((TObject*)0x0,LegDesc.Data(), "h");
  leg->SetNColumns(2);
  leg->SetColumnSeparation(0.2);
  leg->SetTextAlign(32);
  TString snams[] = {"#pi","K","p","#Lambda+#bar{#Lambda}","#Xi","#Omega"};
  Int_t ScaleFactors[] = {10,10,5,1,1,1,1};
//  for(Int_t i=0;i<7;i++)
  for(Int_t i=0;i<nbw;i++) {
    TGraphErrors *spec = GetSpectra(Form("Spectra_%s_%i_cent_%i_%s",syspf.Data(),i,0,fittypePF.Data()));
    spec->SetLineColor(cols+i);
    spec->GetYaxis()->SetTitle("#frac{1}{#it{N}_{ev}}#frac{1}{2#pi#it{p}_{T}}#frac{d^{2}#it{N}}{d#it{y}d#it{p}_{T}} [GeV^{2}]");
    spec->GetXaxis()->SetTitle("#it{p}_{T} (GeV/#it{c})");
    spec->Draw(i?"SAME P":"AP");
    TF1 *fit1 = GetFunc(Form("Fit_%s_%i_cent_%i_%s",syspf.Data(),i,0,fittypePF.Data()));
    fit1->SetLineColor(cols+i);
    fit1->Draw("SAME L");
    leg->AddEntry(spec,Form("%s%s",snams[i].Data(),ScaleFactors[i]==1?"":Form(" #times %i",ScaleFactors[i])),"L");
  }
  SetupFitType(kPCE155);
  TLegend *leg2 = Legend(.75,0.655667,0.987805,.74);
  TF1 *dummyf1 = new TF1("dummyf1","1",0,1);
  TF1 *dummyf2 = new TF1("dummyf1","1",0,1);
  dummyf2->SetLineStyle(2);
  dummyf1->SetLineColor(kBlack);
  dummyf2->SetLineColor(kBlack);
  dummyf1->SetLineWidth(2);
  dummyf2->SetLineWidth(2);
  leg2->AddEntry(dummyf1,"Normal","L");
  leg2->AddEntry(dummyf2,"PCE 155","L");
  leg2->Draw();
  for(Int_t i=0;i<nbw;i++) {
    TF1 *fit2 = GetFunc(Form("Fit_%s_%i_cent_%i_%s",syspf.Data(),i,0,fittypePF.Data()));
    fit2->SetLineColor(cols+i);
    fit2->SetLineStyle(2);
    fit2->Draw("SAME L");
  }
  leg->Draw();
  c->Print("../Figures/SpectraPbPb.pdf");
};
void DrawRatioPlotsMS(FitDesc lfittype) {
  OnMultiStrange=kTRUE;
  SetupFitType(lfittype);
  TCanvas *c = BuildCanvasMatrix(2,3,120,250,0.2,0.30,0.23,0.01);
  SystDesc sds = kPbPb276MS;//{kPbPb276,kpPb502,kpp7};
  Int_t centbin1=0;
  Int_t centbin2=3;
  Int_t droff=0;
  //if(OnMultiStrange) { sds[0]= kPbPb276MS; sds[2]=kpp7MS; droff=3;};
  for(Int_t cs=0;cs<2;cs++) {
      for(Int_t sp=0;sp<3;sp++) {
      SetupFitType(fittype);
      TPad *tp = (TPad*)c->FindObject(Form("tp_%i_%i",cs,sp));
      tp->cd();
      TGraphErrors *grhm = GetGraph(sds,sp+3*cs,centbin1);
      grhm->SetMarkerStyle(20);
      grhm->SetMarkerColor(kBlack);
      grhm->Draw("AP");
      TGraphErrors *grlm = GetGraph(sds,sp+3*cs,centbin2);
      grlm->SetMarkerStyle(24);
      grlm->SetMarkerColor(kBlack);
      grlm->Draw("SAME P");
      TLine *tl = new TLine(-0.1,RatiosInSigma?0:1,3.55,RatiosInSigma?0:1);
      tl->SetLineStyle(2);
      tl->Draw("SAME");
    }
  }
  // TLatex *tlat = new TLatex();
  // tlat->SetTextFont(43);
  // TPad *tp = (TPad*)c->FindObject("tp_0_2");
  // tp->cd();
  // TArrow *ar = new TArrow(0.5,0.2,3,0.2,0.02,"|-----|");
  // ar->SetLineWidth(3);
  // ar->Draw();
  // tlat->SetTextSize(25);
  // tlat->SetTextAlign(22);
  // tlat->DrawLatex(1.75,0.37,"Fit range");
  // tlat->SetTextAlign(11);

  TPad *tp = (TPad*)c->FindObject("mask");
  tp->cd();
  TLatex *tlat = new TLatex();
  tlat->SetTextFont(43);
  tlat->SetTextSize(27);
  tlat->SetTextAngle(90);
  tlat->DrawLatex(0.035,.44,"Data/fit");
  tlat->SetTextAngle(0);
  TString histitle(LegDescNoMulti);
  if(fittypePF.Contains("PCE")) histitle.Prepend(Form("PCE #it{T}_{ch} = %s MeV, ",fittypePF(3,fittypePF.Sizeof()).Data()));
  else histitle.Prepend("Single freeze-out, " );
  tlat->SetTextAlign(21);
  tlat->DrawLatex(0.541391,0.95,histitle.Data());
  tlat->SetTextAlign(11);
  /*
  SetupVariables(kPbPb276);
  tlat->DrawLatex(0.0807963,0.954,LegDescNoMulti.Data());
  SetupVariables(kpPb502);
  tlat->DrawLatex(.3817,0.954,LegDescNoMulti.Data());
  SetupVariables(kpp7);
  tlat->DrawLatex(0.7201,0.954,LegDescNoMulti.Data());*/
  tlat->SetTextSize(30);
  const char *splbs[] = {"#pi fitted","K fitted","p fitted","#Lambda predicted","#Xi predicted","#Omega predicted"};
  tlat->DrawLatex(0.137517,0.679,splbs[0]);
  tlat->DrawLatex(0.137517,0.405,splbs[1]);
  tlat->DrawLatex(0.137517,0.145,splbs[2]);
  tlat->DrawLatex(0.569391,.679,splbs[3]);
  tlat->DrawLatex(0.569391,.405,splbs[4]);
  tlat->DrawLatex(0.569391,0.145,splbs[5]);
  tlat->SetTextSize(27);
  tlat->DrawLatex(.45,0.0253906,"#it{p}_{T} (GeV/#it{c})");
  // tlat->SetTextSize(25);
  // tlat->DrawLatex(.15,0.590047,"0.5 < #it{p}_{T} < 3 (GeV/#it{c})");

  TGraph *dummyblank = new TGraph();
  dummyblank->SetMarkerStyle(24);
  TGraph *dummyfull = new TGraph();
  dummyfull->SetMarkerStyle(20);
  TLegend *legpbpb = Legend(0.112649, 0.291469, 0.55298, 0.376777 );//0.191225,0.537109,0.490894,0.837891);
//  TLegend *legpbpb = Legend(0.112649, 0.829375, 0.55298, 0.913594 );//0.191225,0.537109,0.490894,0.837891);
  legpbpb->SetNColumns(2);
  legpbpb->AddEntry(dummyfull,PbPbBinsMS[centbin1],"P");
  legpbpb->AddEntry(dummyblank,PbPbBinsMS[centbin2],"P");
  legpbpb->Draw();
  /*TLegend *legppb = Legend(.37,.54,.68,.84);
  legppb->SetNColumns(2);
  legppb->AddEntry(dummyfull,pPbBins[0],"P");
  legppb->AddEntry(dummyblank,pPbBins[6],"P");
  legppb->Draw();
  TLegend *legpp = Legend(.67,.54,.98,.84);
  legpp->SetNColumns(2);
  legpp->AddEntry(dummyfull,ppBins[0],"P");
  legpp->AddEntry(dummyblank,ppBins[9],"P");
  legpp->Draw();
  const char *mssubfix="";
  if(OnMultiStrange) mssubfix="_MS";*/
  c->Print(Form("../Figures/%s_MS%s.pdf",RatiosInSigma?"NSigma":"DataToFitRatios",fittypePF.Data()));
};
